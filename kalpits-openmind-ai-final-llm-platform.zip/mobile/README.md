# OpenMind Mobile Shell

A minimal Android WebView shell for the OpenMind web application.

It is deliberately a thin client:
- OpenMind server remains the application/runtime.
- The configured local LLM remains outside the APK.
- Large model weights are not copied into the Android application.
- For a phone-only setup, run the OpenMind server in Termux and build/install this shell separately.

Default URL: `http://127.0.0.1:3000`

Change `MainActivity.java` if the server is hosted elsewhere.

The project requires a compatible Android Gradle Plugin/Gradle environment. The exact Gradle version should be selected to match the Android build environment being used.
