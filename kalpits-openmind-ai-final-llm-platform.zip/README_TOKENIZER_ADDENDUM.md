# Tokenizer addition

The LLM training stack now includes an explicit tokenizer utility based on Hugging Face `AutoTokenizer`. This supports fast tokenizers and model families whose tokenizer is backed by SentencePiece through Transformers.

The tokenizer is saved alongside every trained LoRA adapter, making preprocessing reproducible between training and later inference.
