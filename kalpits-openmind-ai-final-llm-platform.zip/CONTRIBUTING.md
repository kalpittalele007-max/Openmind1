# Contributing to KALPIT's OpenMind AI

## Fast start

```bash
pnpm install
pnpm dev
pnpm check
pnpm test
pnpm build
```

The app is a Vite + React + Tailwind client with an Express + tRPC server. AI calls stay server-side in `server/_core/llm.ts`; public web retrieval and verification live in `server/research.ts`; the primary UI lives in `client/src/pages/Home.tsx`.

## Safe contribution rules

1. Never commit `.env`, API keys, OAuth tokens, personal `data/openmind-memory.json`, uploaded documents, or database dumps.
2. Keep external calls bounded with timeouts and never add `setInterval` or in-process cron timers.
3. Add a Vitest test for each new safety boundary, parser, router contract, or durable workflow.
4. Keep user-visible uncertainty explicit. Do not turn a missing source into a confident answer.
5. Use server-side procedures for secrets and external integrations. The browser must not receive the AI gateway key.

## Extending the research pipeline

- Add intent recognition in `recognizePattern()` when a new question family needs a different plan.
- Keep `runResearch()` source-grounded: retrieval → source reading → synthesis → skeptical verification.
- Add structured output schemas when adding new AI passes.
- Add source and timing details to results so the UI can explain what happened.

## Daily proof review

The app includes `POST /api/scheduled/daily-review`. It is intentionally cron-only and rechecks saved research memories using the same bounded research pipeline. After the app is deployed to a public URL, create the daily Heartbeat job from an owner-enabled shell:

```bash
openmind-heartbeat create \
  --name openmind-daily-review \
  --cron "0 0 4 * * *" \
  --path /api/scheduled/daily-review \
  --description "Recheck saved OpenMind research claims daily"
```

The callback is UTC and the endpoint must be deployed before the job is created. Inspect or pause the job with `openmind-heartbeat list`, `openmind-heartbeat logs --task-uid <uid>`, and `openmind-heartbeat update --task-uid <uid> --enable=false`.

## Pull requests

Describe the user-facing change, list the tests run, and call out any new environment variables. Keep commits focused and avoid generated `dist/` or `node_modules/` files.
