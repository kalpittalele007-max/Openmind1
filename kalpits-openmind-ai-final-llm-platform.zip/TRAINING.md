# OpenMind Learning & Evaluation Pack

This release adds a 5,600-example instruction corpus covering math, coding, reasoning, tool use, research, safety/prompt injection, long-context retrieval, multimodal chart interpretation, agent planning, and communication.

## Important
This is not weight training of a foundation model. The corpus is used as behavioral exemplars by the Mega Agent and as a reproducible evaluation set. Actual model-weight fine-tuning requires a compatible model provider/local model and compute.

## Commands
- `pnpm mega:validate-learning` validates the corpus.
- `pnpm mega:eval` reports coverage.

The agent retrieves a small, relevant subset of examples for each task so the full corpus is not placed into the context window.
