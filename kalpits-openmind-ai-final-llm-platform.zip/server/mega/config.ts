import fs from "node:fs/promises";
import path from "node:path";
export type OpenMindConfig={model?:string; fastModel?:string; maxAgentTurns?:number; outputStyle?:string; theme?:string; keybindings?:Record<string,string>; permissions?:Record<string,string>};
const file=()=>path.resolve(process.env.OPENMIND_CONFIG || ".openmind/config.json");
export async function loadConfig():Promise<OpenMindConfig>{try{return JSON.parse(await fs.readFile(file(),"utf8"));}catch{return {};}}
export async function saveConfig(patch:OpenMindConfig){const f=file(); await fs.mkdir(path.dirname(f),{recursive:true}); const next={...(await loadConfig()),...patch}; await fs.writeFile(f,JSON.stringify(next,null,2)); return next;}
