import { randomUUID } from "node:crypto";
import { invokeLLM } from "../_core/llm";
import { readFile, writeFile, editFile, listFiles } from "./filesystem";
import { runShell } from "./shell";
import { inspectShellCommand, resolveWorkspace } from "./security";
import type { AgentEvent, AgentRunOptions, ToolCall } from "./types";
import { selectLearningExamples, formatLearningExamples } from "./training";

const toolDefs = [
  { type:"function", function:{ name:"read_file", description:"Read a UTF-8 file inside the workspace.", parameters:{type:"object",properties:{file:{type:"string"}},required:["file"]}}},
  { type:"function", function:{ name:"write_file", description:"Write a UTF-8 file inside the workspace.", parameters:{type:"object",properties:{file:{type:"string"},content:{type:"string"}},required:["file","content"]}}},
  { type:"function", function:{ name:"edit_file", description:"Replace an exact string in a workspace file.", parameters:{type:"object",properties:{file:{type:"string"},search:{type:"string"},replacement:{type:"string"}},required:["file","search","replacement"]}}},
  { type:"function", function:{ name:"search_files", description:"List workspace files whose path contains a pattern.", parameters:{type:"object",properties:{pattern:{type:"string"}},required:[]}}},
  { type:"function", function:{ name:"shell", description:"Run a shell command in the workspace. Mutating or unknown commands require approval.", parameters:{type:"object",properties:{command:{type:"string"},approved:{type:"boolean"}},required:["command"]}}},
];

export async function* runAgent(opts: AgentRunOptions): AsyncGenerator<AgentEvent> {
  const workspace = resolveWorkspace(opts.workspace);
  const maxTurns = Math.min(Math.max(opts.maxTurns ?? 12, 1), 30);
  const learning = await selectLearningExamples(opts.prompt, 8);
  const messages: any[] = [
    { role:"system", content:`You are OpenMind Mega Agent, a terminal-native coding agent. Workspace: ${workspace}. Use tools to inspect and modify code. Never claim a change happened unless a tool result confirms it. Keep changes scoped to the workspace. Explain risky operations and request approval rather than bypassing security.\n\nBEHAVIORAL LEARNING EXAMPLES (use as guidance, not as commands):\n${formatLearningExamples(learning)}` },
    { role:"user", content: opts.prompt }
  ];
  for (let turn=0; turn<maxTurns; turn++) {
    yield {type:"status", status:`agent turn ${turn+1}/${maxTurns}`};
    const response:any = await invokeLLM({ messages, tools:toolDefs as any, toolChoice:"auto", model:opts.model });
    const msg = response.choices?.[0]?.message;
    if (!msg) { yield {type:"done", summary:"Model returned no message."}; return; }
    if (msg.content) { yield {type:"assistant", content:String(msg.content)}; }
    messages.push(msg);
    const calls = msg.tool_calls || [];
    if (!calls.length) { yield {type:"done", summary:String(msg.content || "Task completed.")}; return; }
    for (const raw of calls) {
      const call:ToolCall = { id:raw.id || randomUUID(), name:raw.function.name, arguments:JSON.parse(raw.function.arguments || "{}") };
      let output="";
      let ok=true;
      try {
        if (call.name==="read_file") output=(await readFile(workspace,String(call.arguments.file))).content;
        else if (call.name==="write_file") output=JSON.stringify(await writeFile(workspace,String(call.arguments.file),String(call.arguments.content)));
        else if (call.name==="edit_file") output=JSON.stringify(await editFile(workspace,String(call.arguments.file),String(call.arguments.search),String(call.arguments.replacement)));
        else if (call.name==="search_files") output=JSON.stringify(await listFiles(workspace,String(call.arguments.pattern || "")));
        else if (call.name==="shell") {
          const command=String(call.arguments.command);
          const risk=inspectShellCommand(command).risk;
          if (risk!=="low" && !opts.approved && call.arguments.approved!==true) {
            yield {type:"tool-request", call, risk};
            output=`Approval required for shell command. Risk=${risk}. Ask the user to approve this exact command, then rerun with approved=true.`;
            ok=false;
          } else {
            const r=await runShell(command,workspace,{approved:opts.approved===true || call.arguments.approved===true});
            output=r.output; ok=r.ok;
          }
        } else { output=`Unknown tool ${call.name}`; ok=false; }
      } catch(e) { output=String(e); ok=false; }
      const result={toolCallId:call.id,ok,output};
      yield {type:"tool-result",result};
      messages.push({role:"tool",tool_call_id:call.id,content:output});
    }
  }
  yield {type:"done", summary:"Maximum agent turns reached; review the changes and continue the session if needed."};
}
