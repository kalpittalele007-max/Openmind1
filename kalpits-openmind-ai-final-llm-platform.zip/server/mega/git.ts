import { runShell } from "./shell";
export async function worktreeCreate(repo:string, name:string, branch:string) {
  return runShell(`git worktree add -b ${quote(branch)} ${quote(name)} HEAD`, repo, {approved:true});
}
export async function worktreeRemove(repo:string, name:string) {
  return runShell(`git worktree remove ${quote(name)}`, repo, {approved:true});
}
export async function worktreeList(repo:string) { return runShell("git worktree list --porcelain", repo, {approved:false}); }
function quote(s:string){ if(!/^[A-Za-z0-9_./-]+$/.test(s)) throw new Error("Unsafe git worktree name."); return s; }
