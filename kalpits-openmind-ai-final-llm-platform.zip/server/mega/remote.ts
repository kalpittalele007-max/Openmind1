import { randomUUID } from "node:crypto";
type RemoteSession={id:string;createdAt:string;status:"waiting"|"connected"|"closed";events:string[]};
const sessions=new Map<string,RemoteSession>();
export function createRemoteSession(){const s={id:randomUUID(),createdAt:new Date().toISOString(),status:"waiting" as const,events:[]};sessions.set(s.id,s);return s;}
export function closeRemoteSession(id:string){const s=sessions.get(id);if(!s)throw new Error("Remote session not found");s.status="closed";return s;}
export function listRemoteSessions(){return [...sessions.values()];}
