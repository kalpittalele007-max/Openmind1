import os from "node:os";
import process from "node:process";
export function diagnostics(){
  const mem=process.memoryUsage();
  return {timestamp:new Date().toISOString(),node:process.version,platform:process.platform,arch:process.arch,cpuCount:os.cpus().length,load:os.loadavg(),memory:{rss:mem.rss,heapUsed:mem.heapUsed,heapTotal:mem.heapTotal,external:mem.external},uptime:process.uptime(),pid:process.pid};
}
