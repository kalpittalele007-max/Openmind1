export type PermissionDecision = "allow-once" | "allow-always" | "deny";
export type RiskLevel = "low" | "medium" | "high" | "blocked";

export type ToolPermission = {
  tool: string;
  decision: PermissionDecision;
  paths?: string[];
  commands?: string[];
  updatedAt: string;
};

export type ToolCall = {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
};

export type ToolResult = {
  toolCallId: string;
  ok: boolean;
  output: string;
  risk?: RiskLevel;
};

export type AgentEvent =
  | { type: "assistant"; content: string }
  | { type: "tool-request"; call: ToolCall; risk: RiskLevel }
  | { type: "tool-result"; result: ToolResult }
  | { type: "status"; status: string }
  | { type: "done"; summary: string };

export type AgentRunOptions = {
  prompt: string;
  workspace?: string;
  maxTurns?: number;
  approved?: boolean;
  model?: string;
};
