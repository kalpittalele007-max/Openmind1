
export const slashCommands = [
  "/help","/config","/memory","/agent","/plugin","/voice","/git","/session",
  "/tasks","/diagnostics","/project","/mcp","/worktree","/review","/capabilities"
] as const;
export const builtInSkills = [
  {id:"coding-agent",description:"Inspect, edit, test and review a codebase"},
  {id:"research",description:"Retrieve, synthesize and verify information"},
  {id:"document-analysis",description:"Read and cross-check long documents"},
  {id:"git-worktree",description:"Isolate parallel implementation tasks"},
  {id:"diagnostics",description:"Inspect runtime and performance health"},
  {id:"mcp",description:"Discover external MCP tools and resources"},
];
export function resolveCommand(input:string){const name=input.trim().split(/\s+/)[0]; return slashCommands.includes(name as any)?name:null;}
