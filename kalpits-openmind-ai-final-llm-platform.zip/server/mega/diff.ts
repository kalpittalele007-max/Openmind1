import { readFile } from "./filesystem";
import { safePath } from "./security";
import fs from "node:fs/promises";
export async function checkpoint(workspace:string,file:string){
  const target=safePath(workspace,file); const content=await fs.readFile(target,"utf8");
  const cp=`${target}.openmind-checkpoint`; await fs.writeFile(cp,content,"utf8"); return {checkpoint:cp};
}
export async function diffAgainstCheckpoint(workspace:string,file:string){
  const target=safePath(workspace,file), cp=`${target}.openmind-checkpoint`;
  const [a,b]=await Promise.all([fs.readFile(cp,"utf8"),fs.readFile(target,"utf8")]);
  const A=a.split("\n"),B=b.split("\n"), out:string[]=[];
  const n=Math.max(A.length,B.length); for(let i=0;i<n;i++){if(A[i]!==B[i]){out.push(`@@ line ${i+1} @@`);if(A[i]!==undefined)out.push(`- ${A[i]}`);if(B[i]!==undefined)out.push(`+ ${B[i]}`);}}
  return {file:target,changes:out};
}
export async function preview(workspace:string,file:string,lines=80){const r=await readFile(workspace,file); return r.content.split("\n").slice(0,lines).join("\n");}
