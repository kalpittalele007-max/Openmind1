
import readline from "node:readline";
import { runAgent } from "./agent";
import { runShell } from "./shell";
import { inspectShellCommand, resolveWorkspace } from "./security";
import { toMarkdown, toSummary } from "./capabilities";
const workspace=resolveWorkspace(process.env.OPENMIND_WORKSPACE);
console.log(`OpenMind Mega CLI\nworkspace: ${workspace}\nCommands: /help /shell <cmd> /risk <cmd> /capabilities [md] /quit`);
const rl=readline.createInterface({input:process.stdin,output:process.stdout,prompt:"openmind> ",terminal:true});
rl.prompt();
rl.on("line",async line=>{
  const q=line.trim(); if(!q){rl.prompt();return;}
  try{
    if(q==="/quit"){rl.close();return;}
    if(q==="/help"){console.log("/shell executes guarded shell commands; /risk inspects a command; otherwise input is an agent task.");}
    else if(q.startsWith("/risk ")){console.log(inspectShellCommand(q.slice(6)));}
    else if(q.startsWith("/shell ")){const c=q.slice(7);const r=await runShell(c,workspace,{approved:false});console.log(r.output);}
    else if(q==="/capabilities"){console.log(toSummary());}
    else if(q==="/capabilities md"){console.log(toMarkdown());}
    else {for await(const e of runAgent({prompt:q,workspace,approved:false})) {if(e.type==="assistant")console.log(e.content);else if(e.type==="tool-request")console.log(`[approval required] ${e.call.name} risk=${e.risk}`);else if(e.type==="tool-result")console.log(e.result.output);else if(e.type==="status")console.log(`[${e.status}]`);}}
  }catch(e){console.error(String(e))}
  rl.prompt();
});
