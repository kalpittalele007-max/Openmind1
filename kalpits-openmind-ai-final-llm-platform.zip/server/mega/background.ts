import { randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import type { ChildProcess } from "node:child_process";
type Task={id:string;command:string;status:"running"|"done"|"failed"|"cancelled";output:string;startedAt:string;process?:ChildProcess};
const tasks=new Map<string,Task>();
export function startBackground(command:string,cwd:string){
  const id=randomUUID(); const task:Task={id,command,status:"running",output:"",startedAt:new Date().toISOString()};
  const p=spawn("bash",["-lc",command],{cwd}); task.process=p; tasks.set(id,task);
  p.stdout?.on("data",d=>task.output+=d.toString()); p.stderr?.on("data",d=>task.output+=d.toString());
  p.on("close",code=>{ if(task.status==="running") task.status=code===0?"done":"failed"; task.output+=`\n[exit ${code??-1}]`; task.process=undefined; });
  return {id,status:task.status};
}
export function listTasks(){return [...tasks.values()].map(({process,...t})=>t)}
export function getTask(id:string){const t=tasks.get(id); if(!t) throw new Error("Task not found"); const {process,...safe}=t; return safe;}
export function cancelTask(id:string){const t=tasks.get(id); if(!t) throw new Error("Task not found"); t.process?.kill("SIGTERM"); t.status="cancelled"; return getTask(id);}
