import { spawn } from "node:child_process";
import readline from "node:readline";
export type MCPServer={id:string;command:string;args?:string[]};
export async function mcpListTools(server:MCPServer, timeoutMs=8000){
  return await new Promise<any>((resolve,reject)=>{
    const p=spawn(server.command,server.args||[],{stdio:["pipe","pipe","pipe"]});
    const timer=setTimeout(()=>{p.kill();reject(new Error("MCP server timeout"));},timeoutMs);
    const rl=readline.createInterface({input:p.stdout});
    const id=1;
    p.stderr.on("data",()=>{});
    rl.on("line",line=>{try{const msg=JSON.parse(line); if(msg.id===id){clearTimeout(timer); p.kill(); resolve(msg.result||msg.error);}}catch{}});
    p.on("error",e=>{clearTimeout(timer);reject(e)});
    p.stdin.write(JSON.stringify({jsonrpc:"2.0",id,method:"tools/list",params:{}})+"\n");
  });
}
