import fs from "node:fs/promises";
import path from "node:path";
export type SessionMessage={role:string;content:string;ts:string};
const dir=()=>path.resolve(process.env.OPENMIND_SESSION_DIR||".openmind/sessions");
export async function saveSession(id:string,messages:SessionMessage[]){await fs.mkdir(dir(),{recursive:true});await fs.writeFile(path.join(dir(),`${id}.json`),JSON.stringify({id,messages,updatedAt:new Date().toISOString()}));}
export async function loadSession(id:string){return JSON.parse(await fs.readFile(path.join(dir(),`${id}.json`),"utf8"));}
export function compactContext(messages:SessionMessage[],maxChars=50000){if(messages.reduce((n,m)=>n+m.content.length,0)<=maxChars)return messages; const keep=messages.slice(-Math.max(10,Math.floor(messages.length/2))); return [{role:"system",content:"Earlier conversation was compacted. Preserve decisions and unresolved tasks from the retained transcript.",ts:new Date().toISOString()},...keep];}
