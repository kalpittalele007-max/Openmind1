import { randomUUID } from "node:crypto";
import { startBackground, listTasks } from "./background";
type Cron={id:string;command:string;intervalMs:number;workspace:string;nextRun:string;timer?:ReturnType<typeof setInterval>};
const crons=new Map<string,Cron>();
export function createCron(command:string,workspace:string,intervalMs:number){
  if(intervalMs<60000) throw new Error("Minimum scheduled interval is 60 seconds.");
  const id=randomUUID(); const c:Cron={id,command,workspace,intervalMs,nextRun:new Date(Date.now()+intervalMs).toISOString()};
  c.timer=setInterval(()=>{startBackground(command,workspace);c.nextRun=new Date(Date.now()+intervalMs).toISOString();},intervalMs); crons.set(id,c); return {id,command,intervalMs,nextRun:c.nextRun};
}
export function listCrons(){return [...crons.values()].map(({timer,...c})=>c)}
export function deleteCron(id:string){const c=crons.get(id);if(!c)throw new Error("Cron not found");if(c.timer)clearInterval(c.timer);crons.delete(id);return {success:true,id};}
