import fs from "node:fs/promises";
import path from "node:path";
import { safePath, resolveWorkspace } from "./security";

export async function readFile(workspace: string, file: string) {
  const target = safePath(workspace, file);
  return { path: target, content: await fs.readFile(target, "utf8") };
}
export async function writeFile(workspace: string, file: string, content: string) {
  const target = safePath(workspace, file);
  await fs.mkdir(path.dirname(target), { recursive: true });
  await fs.writeFile(target, content, "utf8");
  return { path: target, bytes: Buffer.byteLength(content) };
}
export async function editFile(workspace: string, file: string, search: string, replacement: string) {
  const target = safePath(workspace, file);
  const before = await fs.readFile(target, "utf8");
  if (!before.includes(search)) throw new Error("Search text was not found.");
  const after = before.replace(search, replacement);
  await fs.writeFile(target, after, "utf8");
  return { path: target, changed: true, before, after };
}
export async function listFiles(workspace: string, pattern = "") {
  const base = resolveWorkspace(workspace);
  const out: string[] = [];
  async function walk(dir: string) {
    for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
      if (["node_modules",".git","dist","build"].includes(entry.name)) continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) await walk(full);
      else {
        const rel = path.relative(base, full);
        if (!pattern || rel.toLowerCase().includes(pattern.toLowerCase())) out.push(rel);
      }
    }
  }
  await walk(base);
  return out.slice(0, 5000);
}
export async function fileExists(workspace: string, file: string) {
  try { await fs.access(safePath(workspace, file)); return true; } catch { return false; }
}

export async function editNotebookCell(workspace:string,file:string,index:number,source:string){
  const target=safePath(workspace,file); if(!target.endsWith(".ipynb")) throw new Error("Notebook editor requires .ipynb");
  const notebook=JSON.parse(await fs.readFile(target,"utf8"));
  if(!Array.isArray(notebook.cells)||index<0||index>=notebook.cells.length) throw new Error("Notebook cell index out of range.");
  notebook.cells[index].source=source.split("\n").map((x,i,a)=>i<a.length-1?x+"\n":x);
  await fs.writeFile(target,JSON.stringify(notebook,null,1),"utf8"); return {path:target,index};
}
