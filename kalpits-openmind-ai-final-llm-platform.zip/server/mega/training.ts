import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

export type LearningExample = { id:string; category:string; instruction:string; response:string; tags:string[] };
const corpusPath = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../data/training/openmind_instruction_corpus.jsonl");
let cached: LearningExample[] | null = null;

export async function loadLearningCorpus(): Promise<LearningExample[]> {
  if (cached) return cached;
  const raw = await readFile(corpusPath, "utf8");
  cached = raw.split(/\r?\n/).filter(Boolean).map(line => JSON.parse(line) as LearningExample);
  return cached;
}

export async function selectLearningExamples(prompt:string, limit=8): Promise<LearningExample[]> {
  const corpus = await loadLearningCorpus();
  const terms = new Set(prompt.toLowerCase().split(/[^a-z0-9+#.-]+/).filter(x => x.length > 2));
  const scored = corpus.map(ex => {
    const hay = `${ex.category} ${ex.instruction} ${ex.tags.join(" ")}`.toLowerCase();
    let score = 0;
    for (const t of terms) if (hay.includes(t)) score += 1;
    if (/code|debug|repo|file|git|shell/.test(prompt.toLowerCase()) && ex.category === "coding") score += 3;
    if (/research|source|fact|current|evidence/.test(prompt.toLowerCase()) && ex.category === "research") score += 3;
    if (/safe|danger|delete|inject|permission/.test(prompt.toLowerCase()) && ex.category === "safety") score += 3;
    return { ex, score };
  }).sort((a,b) => b.score-a.score);
  return scored.slice(0, limit).map(x => x.ex);
}

export function formatLearningExamples(examples:LearningExample[]) {
  return examples.map((e,i) => `EXAMPLE ${i+1} [${e.category}]\nUser: ${e.instruction}\nPreferred behavior: ${e.response}`).join("\n\n");
}
