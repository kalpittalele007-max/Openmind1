import { spawn } from "node:child_process";
import type { ToolResult } from "./types";
import { commandRisk, resolveWorkspace, inspectShellCommand } from "./security";

export async function runShell(command: string, workspace?: string, opts?: { approved?: boolean; timeoutMs?: number; signal?: AbortSignal }): Promise<ToolResult> {
  const inspection = inspectShellCommand(command);
  if (inspection.risk === "blocked") return { toolCallId: "shell", ok: false, output: inspection.reasons.join(" "), risk: "blocked" };
  if (!inspection.allowedWithoutApproval && !opts?.approved) {
    return { toolCallId: "shell", ok: false, output: `Approval required. Risk=${inspection.risk}. ${inspection.reasons.join(" ")}`, risk: inspection.risk };
  }
  const cwd = resolveWorkspace(workspace);
  return await new Promise(resolve => {
    const child = spawn("bash", ["-lc", command], { cwd, env: process.env, detached: false });
    let output = "";
    const append = (b: Buffer) => { output += b.toString(); if (output.length > 200_000) output = output.slice(-200_000); };
    child.stdout.on("data", append); child.stderr.on("data", append);
    const timer = setTimeout(() => child.kill("SIGTERM"), opts?.timeoutMs ?? 120_000);
    const abort = () => child.kill("SIGTERM");
    opts?.signal?.addEventListener("abort", abort, { once: true });
    child.on("error", e => { clearTimeout(timer); resolve({ toolCallId: "shell", ok: false, output: String(e), risk: inspection.risk }); });
    child.on("close", code => {
      clearTimeout(timer); opts?.signal?.removeEventListener("abort", abort);
      resolve({ toolCallId: "shell", ok: code === 0, output: `${output}\n[exit ${code ?? -1}]`, risk: inspection.risk });
    });
  });
}
