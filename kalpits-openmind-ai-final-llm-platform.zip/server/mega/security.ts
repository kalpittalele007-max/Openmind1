import path from "node:path";
import fs from "node:fs";
import { createHash, randomUUID } from "node:crypto";
import type { RiskLevel, ToolPermission } from "./types";

const BLOCKED = [
  /\brm\s+-rf\s+\/(?:\s|$)/i,
  /\brm\s+-rf\s+~(?:\s|$)/i,
  /\bmkfs(?:\.[\w-]+)?\b/i,
  /\bdd\s+if=.*\s+of=\/dev\//i,
  /:\(\)\s*\{\s*:\|:&\s*\};:/, // fork bomb
  /\bcurl\b[^|\n]*\|\s*(?:ba)?sh\b/i,
  /\bwget\b[^|\n]*\|\s*(?:ba)?sh\b/i,
  /\beval\s*\(/i,
  /\b(?:sudo|su)\b/i,
  /\bchmod\s+777\b/i,
  /\b(?:history|fc)\s+-(?:c|p)/i,
  /(?:\x1b|\u001b)\[[0-9;?]*[ -/]*[@-~]/,
];

const HIGH_RISK = [
  /\brm\b/i, /\bmv\b/i, /\bcp\b/i, /\bchmod\b/i, /\bchown\b/i,
  /\bgit\s+(?:reset|clean|checkout|restore|push)\b/i,
  /\bnpm\s+(?:publish|uninstall)\b/i, /\bkill(?:all)?\b/i,
];

const SAFE_COMMANDS = new Set([
  "pwd","ls","cat","head","tail","grep","find","git","node","npm","pnpm",
  "python","python3","pip","pytest","vitest","tsc","aapt2","java","gradle",
  "termux-info","echo","printf","wc","sort","uniq","sed","awk","rg"
]);

export function resolveWorkspace(input?: string) {
  const base = path.resolve(input || process.env.OPENMIND_WORKSPACE || process.cwd());
  return base;
}

export function safePath(workspace: string, requested: string) {
  const base = path.resolve(workspace);
  const target = path.resolve(base, requested);
  if (target !== base && !target.startsWith(base + path.sep)) {
    throw new Error("Path is outside the configured OpenMind workspace.");
  }
  return target;
}

export function commandRisk(command: string): RiskLevel {
  if (!command.trim()) return "blocked";
  if (BLOCKED.some(r => r.test(command))) return "blocked";
  const first = command.trim().split(/\s+/)[0].split("/").pop() || "";
  if (HIGH_RISK.some(r => r.test(command))) return "high";
  return SAFE_COMMANDS.has(first) ? "low" : "medium";
}

export function inspectShellCommand(command: string) {
  const risk = commandRisk(command);
  const reasons: string[] = [];
  if (risk === "blocked") reasons.push("Matches a blocked destructive, privilege-escalation, injection, or shell-pipe pattern.");
  if (risk === "high") reasons.push("Potentially mutating or process-control command; explicit approval is required.");
  if (risk === "medium") reasons.push("Command is not on the conservative allowlist; explicit approval is required.");
  return { risk, allowedWithoutApproval: risk === "low", reasons, normalized: command.trim() };
}

const permissions = new Map<string, ToolPermission>();
const permissionFile = () => path.resolve(process.env.OPENMIND_PERMISSION_FILE || ".openmind/permissions.json");
function loadPermissions(){ try { const raw=JSON.parse(fs.readFileSync(permissionFile(),"utf8")); for(const p of raw) permissions.set(`${p.tool}:${p.paths?.join(",") || ""}:${p.commands?.join(",") || ""}`,p); } catch {} }
loadPermissions();
export function setPermission(p: Omit<ToolPermission, "updatedAt">) {
  const entry = { ...p, updatedAt: new Date().toISOString() };
  permissions.set(`${p.tool}:${p.paths?.join(",") || ""}:${p.commands?.join(",") || ""}`, entry);
  try { fs.mkdirSync(path.dirname(permissionFile()),{recursive:true}); fs.writeFileSync(permissionFile(),JSON.stringify([...permissions.values()],null,2)); } catch {}
  return entry;
}
export function listPermissions() { return [...permissions.values()]; }
export function approvalToken(scope: string) {
  return createHash("sha256").update(`${scope}:${randomUUID()}`).digest("hex").slice(0, 32);
}
