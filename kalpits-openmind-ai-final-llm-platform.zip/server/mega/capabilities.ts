/**
 * Missing Capabilities Registry
 * ---------------------------------------------------------------------------
 * Single source of truth for the capability gap between KALPIT's OpenMind AI
 * and a full frontier-grade AI platform (foundation model, reasoning, agents,
 * safety, infra, and research). Organized into 35 capability areas.
 *
 * Consumers:
 *   - server/routers.ts        -> exposes `mega.capabilities` as a tRPC query
 *   - server/mega/commands.ts  -> registers the `/capabilities` slash command
 *   - server/mega/cli.ts       -> `/capabilities` and `/capabilities md` in the REPL
 */

/** A single capability area: a numbered theme with its individual tracked items. */
export type CapabilityArea = {
  /** Stable 1-based index, matches display order. */
  id: number;
  /** Human-readable area name, e.g. "Advanced reasoning". */
  name: string;
  /** Individual capability items within this area. */
  items: string[];
};

/** Aggregate counts across every area — area count and total tracked items. */
export type CapabilityStats = {
  areaCount: number;
  itemCount: number;
};

/**
 * The full registry, in display order. Treat as read-only: callers should
 * go through `getMissingCapabilities()` rather than mutating this directly.
 */
export const missingCapabilities: readonly CapabilityArea[] = [
  {
    id: 1,
    name: "Frontier foundation model",
    items: [
      "Own large-scale foundation model",
      "Frontier-level general intelligence",
      "Frontier-level reasoning",
      "Frontier-level coding intelligence",
      "Frontier-level mathematical reasoning",
      "Frontier-level scientific reasoning",
      "Native instruction-following model",
      "Native tool-use training",
      "Native agentic reasoning training",
    ],
  },
  {
    id: 2,
    name: "Advanced reasoning",
    items: [
      "Deep multi-step reasoning",
      "Reliable complex problem solving",
      "Advanced mathematical reasoning",
      "Advanced scientific reasoning",
      "Long-horizon planning",
      "Self-correction at model level",
      "Robust ambiguity resolution",
      "Reliable reasoning across unfamiliar domains",
    ],
  },
  {
    id: 3,
    name: "Unified multimodal model",
    items: [
      "Native text + image reasoning",
      "Native audio understanding",
      "Native video understanding",
      "Native visual reasoning",
      "Native document + image reasoning",
      "Unified multimodal context",
      "Real-time multimodal interaction",
    ],
  },
  {
    id: 4,
    name: "Advanced voice",
    items: [
      "Real-time conversational voice",
      "Low-latency speech-to-speech",
      "Natural interruption handling",
      "Continuous listening state",
      "Natural turn-taking",
      "Advanced voice emotion/prosody handling",
      "Unified voice + vision + reasoning",
      "Production-grade realtime audio pipeline",
    ],
  },
  {
    id: 5,
    name: "Advanced computer use",
    items: [
      "Reliable visual computer control",
      "Screen understanding",
      "Mouse control",
      "Keyboard control",
      "Application interaction",
      "Browser interaction",
      "GUI navigation",
      "Visual verification after actions",
      "Recovery from unexpected UI states",
    ],
  },
  {
    id: 6,
    name: "Advanced web agent",
    items: [
      "Autonomous web navigation",
      "Multi-step browser interaction",
      "Website login workflows",
      "Form completion",
      "Page interaction",
      "Automatic query refinement",
      "Cross-source contradiction detection",
      "Long-running research sessions",
      "Automatic research planning",
      "Automatic research verification",
    ],
  },
  {
    id: 7,
    name: "Production coding agent",
    items: [
      "Frontier-level coding model",
      "Deep repository understanding",
      "Reliable multi-file implementation",
      "Automatic debugging",
      "Automatic test generation",
      "Automatic test repair",
      "Build-error recovery",
      "Dependency debugging",
      "Architecture-level refactoring",
      "Regression detection",
      "Reliable completion verification",
    ],
  },
  {
    id: 8,
    name: "Secure agent sandbox",
    items: [
      "OS-level filesystem sandbox",
      "OS-level network sandbox",
      "Process isolation",
      "Resource limits",
      "CPU limits",
      "Memory limits",
      "Network allowlists",
      "Filesystem allowlists",
      "Disposable execution environments",
      "Container/VM isolation",
      "Automatic environment cleanup",
    ],
  },
  {
    id: 9,
    name: "Advanced prompt-injection defense",
    items: [
      "Tool-result injection detection",
      "Web-page injection detection",
      "Malicious README detection",
      "Malicious repository-instruction detection",
      "Indirect prompt-injection detection",
      "Context poisoning detection",
      "Tool-output sanitization",
      "Agent instruction hierarchy enforcement",
      "Continuous prompt-injection evaluation",
    ],
  },
  {
    id: 10,
    name: "Advanced tool use",
    items: [
      "Model-native tool selection",
      "Learned tool planning",
      "Tool-result interpretation",
      "Automatic tool retry",
      "Tool failure recovery",
      "Parallel tool planning",
      "Tool dependency planning",
      "Tool-call optimization",
      "Tool-use verification",
    ],
  },
  {
    id: 11,
    name: "Large-scale model routing",
    items: [
      "Automatic model selection",
      "Fast-model routing",
      "Reasoning-model routing",
      "Coding-model routing",
      "Vision-model routing",
      "Long-context-model routing",
      "Research-model routing",
      "Cost-aware routing",
      "Latency-aware routing",
      "Capability-aware routing",
      "Automatic fallback models",
    ],
  },
  {
    id: 12,
    name: "Advanced context management",
    items: [
      "Extremely large context windows",
      "Intelligent context prioritization",
      "Learned context compression",
      "Semantic memory retrieval",
      "Automatic relevance ranking",
      "Cross-session context reconstruction",
      "Long-running agent context",
      "Context conflict resolution",
      "Context poisoning detection",
    ],
  },
  {
    id: 13,
    name: "Advanced memory",
    items: [
      "Structured long-term memory",
      "Episodic memory",
      "Semantic memory",
      "Project memory",
      "User preference memory",
      "Automatic memory formation",
      "Memory relevance scoring",
      "Memory conflict resolution",
      "Memory decay",
      "Memory provenance",
      "Memory safety controls",
    ],
  },
  {
    id: 14,
    name: "Multi-agent system",
    items: [
      "Advanced coordinator agent",
      "Specialized worker agents",
      "Parallel reasoning agents",
      "Agent delegation",
      "Agent result verification",
      "Agent conflict resolution",
      "Agent-to-agent planning",
      "Dynamic worker spawning",
      "Dynamic worker termination",
      "Shared structured workspace",
    ],
  },
  {
    id: 15,
    name: "Advanced MCP",
    items: [
      "Full MCP client",
      "Full MCP server",
      "Stdio transport",
      "SSE transport",
      "WebSocket transport",
      "Dynamic tool discovery",
      "Dynamic resource discovery",
      "Resource subscriptions",
      "Tool permission management",
      "MCP security isolation",
      "MCP server trust management",
    ],
  },
  {
    id: 16,
    name: "Advanced background agents",
    items: [
      "Persistent autonomous agents",
      "Long-running tasks",
      "Scheduled agents",
      "Event-triggered agents",
      "Task retry policies",
      "Failure recovery",
      "Agent health monitoring",
      "Persistent task queues",
      "Distributed task execution",
      "Reliable task resumption",
    ],
  },
  {
    id: 17,
    name: "Advanced git/development workflow",
    items: [
      "Automatic branch creation",
      "Automatic worktree management",
      "Automatic commit generation",
      "Commit verification",
      "Pull-request generation",
      "Pull-request review",
      "Merge conflict resolution",
      "Automatic rollback",
      "CI integration",
      "Release workflow automation",
    ],
  },
  {
    id: 18,
    name: "IDE integration",
    items: [
      "VS Code integration",
      "JetBrains integration",
      "Remote IDE integration",
      "Editor diagnostics",
      "Inline AI coding",
      "Code navigation",
      "Symbol-aware editing",
      "Integrated terminal",
      "Debugger integration",
      "Breakpoint-aware AI debugging",
    ],
  },
  {
    id: 19,
    name: "Desktop/OS integration",
    items: [
      "Native desktop application",
      "Native installers",
      "Automatic updates",
      "System notifications",
      "OS-level integration",
      "Native terminal integration",
      "Secure credential storage",
      "Background service management",
    ],
  },
  {
    id: 20,
    name: "Model infrastructure",
    items: [
      "Distributed model serving",
      "GPU inference infrastructure",
      "Model parallelism",
      "Tensor parallelism",
      "Pipeline parallelism",
      "KV-cache optimization",
      "Dynamic batching",
      "Load balancing",
      "High-availability inference",
      "Model replication",
      "Global inference routing",
    ],
  },
  {
    id: 21,
    name: "Model training",
    items: [
      "Large-scale pretraining",
      "Instruction tuning",
      "Preference optimization",
      "Reinforcement learning",
      "Reasoning training",
      "Tool-use training",
      "Coding training",
      "Multimodal training",
      "Safety training",
      "Continual training",
    ],
  },
  {
    id: 22,
    name: "AI safety infrastructure",
    items: [
      "Automated red-team testing",
      "Jailbreak testing",
      "Prompt-injection testing",
      "Tool-abuse testing",
      "Data-exfiltration testing",
      "Dangerous-command testing",
      "Model behavior monitoring",
      "Safety regression testing",
      "Policy enforcement at model level",
    ],
  },
  {
    id: 23,
    name: "Large-scale evaluation",
    items: [
      "Massive benchmark suite",
      "Coding benchmarks",
      "Reasoning benchmarks",
      "Math benchmarks",
      "Science benchmarks",
      "Long-context benchmarks",
      "Hallucination benchmarks",
      "Tool-use benchmarks",
      "Agent benchmarks",
      "Multimodal benchmarks",
      "Prompt-injection benchmarks",
      "Continuous regression testing",
    ],
  },
  {
    id: 24,
    name: "Production observability",
    items: [
      "Distributed tracing",
      "Model telemetry",
      "Agent telemetry",
      "Tool telemetry",
      "Token accounting",
      "Latency monitoring",
      "Error monitoring",
      "Cost monitoring",
      "Performance dashboards",
      "Automatic anomaly detection",
      "Production incident analysis",
    ],
  },
  {
    id: 25,
    name: "Enterprise-grade security",
    items: [
      "Secrets management",
      "Credential isolation",
      "OAuth integration",
      "Fine-grained access control",
      "Role-based permissions",
      "Audit logs",
      "Encryption at rest",
      "Encryption in transit",
      "Organization-level policies",
      "User-level policies",
      "Data-loss prevention",
    ],
  },
  {
    id: 26,
    name: "Advanced file/document intelligence",
    items: [
      "Native document vision",
      "Table understanding",
      "Complex spreadsheet reasoning",
      "Scanned-document understanding",
      "OCR + reasoning",
      "Cross-document reasoning",
      "Citation-level evidence tracking",
      "Document contradiction detection",
      "Large-document autonomous investigation",
    ],
  },
  {
    id: 27,
    name: "Advanced image generation/understanding",
    items: [
      "Native vision model",
      "Image editing",
      "Image reasoning",
      "Image-to-image understanding",
      "Visual grounding",
      "Object-level reasoning",
      "Diagram understanding",
      "Screenshot reasoning",
      "Consistent image generation",
      "Image-generation evaluation",
    ],
  },
  {
    id: 28,
    name: "Advanced video intelligence",
    items: [
      "Video understanding",
      "Temporal reasoning",
      "Scene understanding",
      "Object tracking",
      "Video summarization",
      "Video question answering",
      "Video generation",
      "Video editing through AI",
      "Long-video analysis",
    ],
  },
  {
    id: 29,
    name: "Real-time information system",
    items: [
      "Live data ingestion",
      "Streaming information processing",
      "Real-time event detection",
      "Real-time source verification",
      "Real-time alerts",
      "Continuous monitoring agents",
      "Event-driven agent execution",
    ],
  },
  {
    id: 30,
    name: "Self-evaluating agent",
    items: [
      "Automatic answer verification",
      "Independent critic model",
      "Automatic test generation",
      "Automatic adversarial testing",
      "Confidence calibration",
      "Failure classification",
      "Root-cause analysis",
      "Automatic retry strategy",
      "Evidence-based completion verification",
    ],
  },
  {
    id: 31,
    name: "Autonomous research system",
    items: [
      "Research planning",
      "Source discovery",
      "Source ranking",
      "Query decomposition",
      "Iterative research",
      "Evidence extraction",
      "Contradiction detection",
      "Evidence graph",
      "Automatic fact verification",
      "Research report generation",
    ],
  },
  {
    id: 32,
    name: "General agent memory + knowledge graph",
    items: [
      "Entity graph",
      "Relationship graph",
      "Temporal knowledge",
      "Source provenance",
      "Confidence tracking",
      "Knowledge updates",
      "Contradiction resolution",
      "Project-specific knowledge graphs",
    ],
  },
  {
    id: 33,
    name: "High-reliability agent loop",
    items: [
      "Plan",
      "Execute",
      "Observe",
      "Verify",
      "Critique",
      "Correct",
      "Retry",
      "Test",
      "Confirm",
      "Complete",
    ],
  },
  {
    id: 34,
    name: "Global scale",
    items: [
      "Multi-region deployment",
      "High availability",
      "Automatic failover",
      "Horizontal scaling",
      "Distributed databases",
      "Distributed queues",
      "CDN integration",
      "Global monitoring",
      "Disaster recovery",
    ],
  },
  {
    id: 35,
    name: "Frontier-model research capability",
    items: [
      "Large-scale experimentation",
      "Model fine-tuning",
      "Distillation",
      "Synthetic-data generation",
      "Reinforcement learning environments",
      "Automated model evaluation",
      "Model ablation testing",
      "Training-data experiments",
      "Architecture experiments",
    ],
  },
];

/** Returns the full capability registry. */
export function getMissingCapabilities(): readonly CapabilityArea[] {
  return missingCapabilities;
}

/** Returns aggregate stats: number of areas and total number of tracked items. */
export function capabilityStats(): CapabilityStats {
  const areaCount = missingCapabilities.length;
  const itemCount = missingCapabilities.reduce((sum, area) => sum + area.items.length, 0);
  return { areaCount, itemCount };
}

/**
 * Finds a single area by numeric id (as a string, e.g. "7") or by a
 * case-insensitive substring match against the area name.
 */
export function findCapabilityArea(query: string): CapabilityArea | undefined {
  const q = query.trim().toLowerCase();
  return missingCapabilities.find(
    (area) => String(area.id) === q || area.name.toLowerCase().includes(q)
  );
}

/**
 * Renders the full registry as a Markdown checklist report.
 * Used by `npm run mega -- capabilities --md` and the `/capabilities md`
 * REPL command so no separate documentation file needs to be kept in sync.
 */
export function toMarkdown(): string {
  const { areaCount, itemCount } = capabilityStats();
  const lines: string[] = [
    "# Major Missing Capabilities",
    "",
    `_${areaCount} areas, ${itemCount} tracked items._`,
    "",
  ];

  for (const area of missingCapabilities) {
    lines.push(`## ${area.id}. ${area.name}`);
    for (const item of area.items) lines.push(`- [ ] ${item}`);
    lines.push("");
  }

  return lines.join("\n");
}

/** Renders a compact, one-line-per-area summary for terminal/CLI output. */
export function toSummary(): string {
  return missingCapabilities
    .map((area) => `${String(area.id).padStart(2, "0")}. ${area.name} (${area.items.length})`)
    .join("\n");
}
