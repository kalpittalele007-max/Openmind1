import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const unauthenticated = { user: undefined, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] } satisfies TrpcContext;

describe("feature route authentication", () => {
  it("protects research execution, document analysis, image generation, website building, and memory", async () => {
    const caller = appRouter.createCaller(unauthenticated);
    await expect(caller.research.run({ query: "private question", saveToMemory: false })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.documents.analyze({ fileName: "notes.txt", mimeType: "text/plain", data: "bm90ZXM=", saveToMemory: false })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.memory.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.images.generate({ prompt: "a test image", style: "minimal", aspect: "square" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.websites.blueprint({ prompt: "A portfolio website for a photographer", framework: "react" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
