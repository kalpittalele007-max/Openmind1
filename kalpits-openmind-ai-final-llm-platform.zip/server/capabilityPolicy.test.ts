import { describe, expect, it } from "vitest";
import { CAPABILITY_LIMITS, OPENMIND_CAPABILITY_POLICY, UNKNOWN_EVIDENCE_RESPONSE, capabilityStatus } from "./_core/capabilityPolicy";

describe("OpenMind capability contract", () => {
  it("does not advertise impossible guarantees", () => {
    expect(Object.values(CAPABILITY_LIMITS).every(value => value === false)).toBe(true);
  });

  it("requires the exact unknown-evidence response", () => {
    expect(UNKNOWN_EVIDENCE_RESPONSE).toBe("No — I don’t know that yet.");
    expect(OPENMIND_CAPABILITY_POLICY).toContain(UNKNOWN_EVIDENCE_RESPONSE);
  });

  it("reports protected boundaries", () => {
    const status = capabilityStatus();
    expect(status.protectedBoundaries).toContain("automatic arbitrary code execution");
    expect(status.protectedBoundaries).toContain("unauthorized destructive or irreversible actions");
    expect(status.guarantees.completeCorrectness).toBe(false);
  });
});
