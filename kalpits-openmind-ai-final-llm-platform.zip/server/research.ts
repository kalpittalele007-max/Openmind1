import { invokeLLM } from "./_core/llm";
import { appendMemory, readMemory, type MemoryItem } from "./memory";
import { fetchPublicResponse, isPublicUrl, retry } from "./security";

type SearchHit = { title: string; url: string; snippet: string };
type SourcePacket = SearchHit & { text: string; fetchStatus: "ok" | "failed" };
export type EvidenceGrade = { title: string; url: string; score: number; label: "strong" | "moderate" | "limited"; basis: string[] };

const RESEARCH_TIMEOUT_MS = 120_000;
const FETCH_TIMEOUT_MS = 8_000;

const withTimeout = async <T>(promise: Promise<T>, ms: number): Promise<T> => {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error("Timed out")), ms);
  });
  try {
    return await Promise.race([promise, timeout]);
  } finally {
    if (timer) clearTimeout(timer);
  }
};

const cleanText = (html: string) =>
  html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();

const safeUrl = (value: string) => {
  try {
    const url = new URL(value, "https://duckduckgo.com");
    return isPublicUrl(url.toString()) ? url.toString() : "";
  } catch {
    return "";
  }
};

function boundaryMessage(query: string) {
  const lower = query.toLowerCase();
  const boundary = /(?:get|break|escape|leave|exit|run)\s+(?:out|outside|beyond)\s+(?:of\s+)?(?:the\s+)?sandbox|(?:escape|break|bypass|circumvent)\s+(?:the\s+)?(?:sandbox|container|restrictions)|(?:extend|increase|remove|ignore)\s+(?:your|the|my)?\s*(?:limit|limits|runtime|permissions)|(?:reveal|show|dump|print)\s+(?:the\s+)?(?:system prompt|hidden instructions)|(?:steal|exfiltrate|dump)\s+(?:credentials|secrets|tokens|keys|data)/i;
  if (!boundary.test(lower)) return null;
  return {
    answer:
      "No — I don't know that yet, and I won't pretend I can extend my limits or leave the sandbox. I can still help with the legitimate part of the task: explain the concept, design a safe architecture, or write code that stays within the current environment.",
    stance: "boundary" as const,
    confidence: 1,
    keyPoints: ["Capability boundary detected", "No sandbox escape or limit extension is attempted", "A safe, in-scope alternative can be designed"],
    sources: [],
    tests: ["Boundary pattern check passed", "No external requests were made"],
    caveats: "This is a safety and scope boundary, not a factual claim about the outside world.",
    verification: { verdict: "safe", issues: [], corrections: [] },
    elapsedMs: 0,
  };
}

async function searchWeb(query: string): Promise<SearchHit[]> {
  const braveKey = process.env.BRAVE_SEARCH_API_KEY?.trim();
  if (braveKey) {
    const api = await withTimeout(retry(() => fetchPublicResponse(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=6`, { headers: { "accept": "application/json", "x-subscription-token": braveKey } })), FETCH_TIMEOUT_MS);
    if (!api.ok) throw new Error(`Configured search API returned ${api.status}`);
    const payload = await api.json() as { web?: { results?: Array<{ title?: string; url?: string; description?: string }> } };
    const results = (payload.web?.results ?? []).map((item) => ({ title: item.title ?? "Untitled source", url: item.url ?? "", snippet: item.description ?? "" })).filter((item) => isPublicUrl(item.url));
    if (results.length) return results;
  }
  const endpoint = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
  const response = await withTimeout(retry(() => fetchPublicResponse(endpoint, { headers: { "user-agent": "OpenMindAI/1.0 research client" } })), FETCH_TIMEOUT_MS);
  if (!response.ok) throw new Error(`Search provider returned ${response.status}`);
  const html = await response.text();
  const hits: SearchHit[] = [];
  const resultPattern = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/gi;
  for (const match of Array.from(html.matchAll(resultPattern))) {
    const rawHref = match[1] ?? "";
    const url = safeUrl(rawHref.includes("uddg=") ? decodeURIComponent(rawHref.split("uddg=")[1]?.split("&")[0] ?? "") : rawHref);
    if (!url || hits.some((hit) => hit.url === url)) continue;
    hits.push({ title: cleanText(match[2] ?? "Untitled source"), url, snippet: cleanText(match[3] ?? "") });
    if (hits.length >= 6) break;
  }
  if (hits.length) return hits;

  const wiki = await withTimeout(retry(() => fetchPublicResponse(`https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(query)}&limit=5&namespace=0&format=json`)), FETCH_TIMEOUT_MS);
  const data = (await wiki.json().catch(() => [])) as unknown[];
  const titles = Array.isArray(data[1]) ? (data[1] as string[]) : [];
  const urls = Array.isArray(data[3]) ? (data[3] as string[]) : [];
  return titles.map((title, index) => ({ title, url: urls[index] ?? `https://en.wikipedia.org/wiki/${encodeURIComponent(title)}`, snippet: "Wikipedia result" }));
}

async function fetchSource(hit: SearchHit): Promise<SourcePacket> {
  try {
    const response = await withTimeout(retry(() => fetchPublicResponse(hit.url, { headers: { "user-agent": "OpenMindAI/1.0 research client" } })), FETCH_TIMEOUT_MS);
    if (!response.ok) throw new Error("source unavailable");
    const html = await response.text();
    return { ...hit, text: cleanText(html).slice(0, 12_000), fetchStatus: "ok" };
  } catch {
    return { ...hit, text: `${hit.snippet} (The full page could not be fetched.)`, fetchStatus: "failed" };
  }
}

const compactSources = (sources: SourcePacket[]) =>
  sources.map((source, index) => `SOURCE ${index + 1}\nTitle: ${source.title}\nURL: ${source.url}\nSnippet: ${source.snippet}\nExtract: ${source.text}`).join("\n\n");

function gradeSources(sources: SourcePacket[]): EvidenceGrade[] {
  return sources.map((source) => {
    const host = new URL(source.url).hostname.toLowerCase();
    const basis: string[] = [];
    let score = source.fetchStatus === "ok" ? 55 : 25;
    basis.push(source.fetchStatus === "ok" ? "page fetched successfully" : "only search snippet available");
    if (/\.gov$|\.edu$|\.int$|official|who\.int|un\.org/.test(host)) { score += 25; basis.push("institutional or primary-looking domain"); }
    else if (/wikipedia|nature|science|reuters|apnews|bbc/.test(host)) { score += 15; basis.push("established reference or newsroom domain"); }
    if (source.text.length > 500) { score += 10; basis.push("substantial extract available"); }
    const label = score >= 75 ? "strong" : score >= 50 ? "moderate" : "limited";
    return { title: source.title, url: source.url, score: Math.min(score, 100), label, basis };
  });
}

const researchSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    answer: { type: "string" },
    stance: { type: "string", enum: ["supported", "mixed", "uncertain"] },
    confidence: { type: "number" },
    keyPoints: { type: "array", items: { type: "string" } },
    sources: { type: "array", items: { type: "object", additionalProperties: false, properties: { title: { type: "string" }, url: { type: "string" }, claim: { type: "string" } }, required: ["title", "url", "claim"] } },
    tests: { type: "array", items: { type: "string" } },
    caveats: { type: "string" },
  },
  required: ["answer", "stance", "confidence", "keyPoints", "sources", "tests", "caveats"],
};

export async function runResearch(query: string, includeMemory = true, userId = 0) {
  const startedAt = Date.now();
  const boundary = boundaryMessage(query);
  if (boundary) return boundary;

  const memory = includeMemory ? await readMemory(userId, 8) : [];
  const hits = await withTimeout(searchWeb(query), RESEARCH_TIMEOUT_MS);
  const sources = await withTimeout(Promise.all(hits.slice(0, 4).map(fetchSource)), RESEARCH_TIMEOUT_MS);
  const memoryContext = memory.length ? `\nUSER CONTEXT (use only when relevant):\n${memory.map((item: MemoryItem) => `- ${item.content}`).join("\n")}` : "";
  const sourceContext = compactSources(sources);

  const draftResponse = await withTimeout(invokeLLM({
    maxTokens: 1600,
    responseFormat: { type: "json_schema", json_schema: { name: "research_report", strict: true, schema: researchSchema } },
    messages: [
      { role: "system", content: "You are OpenMind, a careful research assistant. Answer from the supplied sources only. Compare sources, distinguish facts from inference, include citations using the supplied URLs, and state uncertainty plainly. Your tests must name concrete checks such as cross-source agreement, source accessibility, date relevance, and citation coverage. Never claim to have browsed beyond the supplied source packet." },
      { role: "user", content: `Question: ${query}\n${memoryContext}\n\nSOURCE PACKET:\n${sourceContext}` },
    ],
  }), RESEARCH_TIMEOUT_MS);
  const rawDraft = draftResponse.choices[0]?.message.content;
  const draft = JSON.parse(typeof rawDraft === "string" ? rawDraft : JSON.stringify(rawDraft ?? {})) as { answer: string; stance: "supported" | "mixed" | "uncertain"; confidence: number; keyPoints: string[]; sources: { title: string; url: string; claim: string }[]; tests: string[]; caveats: string };

  const verifyResponse = await withTimeout(invokeLLM({
    maxTokens: 900,
    responseFormat: { type: "json_schema", json_schema: { name: "verification_review", strict: true, schema: { type: "object", additionalProperties: false, properties: { verdict: { type: "string", enum: ["pass", "needs-review", "fail"] }, issues: { type: "array", items: { type: "string" } }, corrections: { type: "array", items: { type: "string" } }, counterEvidence: { type: "array", items: { type: "string" } } }, required: ["verdict", "issues", "corrections", "counterEvidence"] } } },
    messages: [
      { role: "system", content: "You are a skeptical fact checker. Review the draft against the source packet. Look for unsupported claims, source mismatch, overconfidence, and missing caveats. Explicitly look for counter-evidence or source disagreement and include it in counterEvidence. Return only the requested JSON." },
      { role: "user", content: `DRAFT:\n${JSON.stringify(draft)}\n\nSOURCE PACKET:\n${sourceContext}` },
    ],
  }), RESEARCH_TIMEOUT_MS);
  const rawVerification = verifyResponse.choices[0]?.message.content;
  const verification = JSON.parse(typeof rawVerification === "string" ? rawVerification : JSON.stringify(rawVerification ?? {})) as { verdict: "pass" | "needs-review" | "fail"; issues: string[]; corrections: string[]; counterEvidence?: string[] };

  const deterministicTests = [
    `${sources.length} candidate sources collected`,
    `${sources.filter((source) => source.fetchStatus === "ok").length}/${sources.length} source pages fetched successfully`,
    `${new Set(sources.map((source) => new URL(source.url).hostname)).size} distinct source domains represented`,
    `${draft.sources.length} citations attached to the answer`,
  ];

  return {
    ...draft,
    sources: draft.sources.length ? draft.sources : sources.map((source) => ({ title: source.title, url: source.url, claim: source.snippet })),
    tests: [...deterministicTests, ...draft.tests],
    verification,
    evidenceGrades: gradeSources(sources),
    provenance: { answer: "AI synthesis grounded in retrieved public sources", memoryUsed: memory.length > 0, sourceCount: sources.length, fetchedCount: sources.filter((source) => source.fetchStatus === "ok").length, retrievalMode: process.env.BRAVE_SEARCH_API_KEY ? "Brave Search API with fallback" : "Public fallback retrieval" },
    elapsedMs: Date.now() - startedAt,
  };
}

const documentSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    keyPoints: { type: "array", items: { type: "string" } },
    entities: { type: "array", items: { type: "string" } },
    mainPoints: { type: "array", items: { type: "string" } },
    summary: { type: "string" },
    answer: { type: "string" },
    caveats: { type: "string" },
    nextSteps: { type: "array", items: { type: "string" } },
  },
  required: ["keyPoints", "entities", "mainPoints", "summary", "answer", "caveats", "nextSteps"],
};

export async function runDocumentAnalysis(input: { fileName: string; mimeType: string; data: string; question?: string }) {
  const startedAt = Date.now();
  const buffer = Buffer.from(input.data, "base64");
  const supportedText = input.mimeType.includes("text") || /\.(md|txt|csv|json|js|ts|tsx|py|html|css)$/i.test(input.fileName);
  const fileText = supportedText ? buffer.toString("utf8").slice(0, 90_000) : `The uploaded file is ${input.fileName} (${input.mimeType}). Use the attached file content if your model supports file reading.`;
  const extractionWarning = supportedText || input.mimeType === "application/pdf" ? undefined : `Automatic extraction is not available for ${input.mimeType || "this file type"}. The file was stored, but its contents were not parsed; upload a PDF or text-based file for reliable analysis.`;
  const prompt = input.question?.trim() || "What should a careful reader understand from this document?";
  let fileUrl: string | undefined;
  try {
    const { storagePut, storageGetSignedUrl } = await import("./storage");
    const stored = await storagePut(`documents/${input.fileName}`, buffer, input.mimeType || "application/octet-stream");
    fileUrl = await storageGetSignedUrl(stored.key);
  } catch {
    // Storage is optional for local GitHub runs; text analysis still works without it.
  }
  const attachment = fileUrl && input.mimeType === "application/pdf" ? [{ type: "file_url" as const, file_url: { url: fileUrl, mime_type: "application/pdf" as const } }] : [];
  const firstPass = await invokeLLM({
    maxTokens: 1100,
    responseFormat: { type: "json_schema", json_schema: { name: "document_keypoints", strict: true, schema: { type: "object", additionalProperties: false, properties: { keyPoints: { type: "array", items: { type: "string" } }, entities: { type: "array", items: { type: "string" } }, outline: { type: "array", items: { type: "string" } } }, required: ["keyPoints", "entities", "outline"] } } },
    messages: [
      { role: "system", content: "You are the first pass of a document analyst. Extract high-signal key points, entities, and a compact outline. Do not answer the user's question yet." },
      { role: "user", content: [{ type: "text", text: `Document: ${input.fileName}\n${fileText}` }, ...attachment] },
    ],
  });
  const firstRaw = firstPass.choices[0]?.message.content;
  const first = JSON.parse(typeof firstRaw === "string" ? firstRaw : JSON.stringify(firstRaw ?? {})) as { keyPoints: string[]; entities: string[]; outline: string[] };
  const secondPass = await invokeLLM({
    maxTokens: 1500,
    responseFormat: { type: "json_schema", json_schema: { name: "document_analysis", strict: true, schema: documentSchema } },
    messages: [
      { role: "system", content: "You are the second pass of a document analyst. Use the first-pass key points, then reread the supplied document and produce the main points, a concise summary, a direct answer, caveats, and next steps. Be explicit when the document does not contain enough evidence." },
      { role: "user", content: [{ type: "text", text: `Question: ${prompt}\nDocument: ${input.fileName}\nFIRST PASS:\n${JSON.stringify(first)}\nDOCUMENT:\n${fileText}` }, ...attachment] },
    ],
  });
  const secondRaw = secondPass.choices[0]?.message.content;
  const result = JSON.parse(typeof secondRaw === "string" ? secondRaw : JSON.stringify(secondRaw ?? {})) as Record<string, unknown>;
  return { ...result, firstPass: first, fileName: input.fileName, stored: Boolean(fileUrl), extractionWarning, elapsedMs: Date.now() - startedAt };
}

export async function rememberResearch(userId: number, query: string, answer: string) {
  return appendMemory(userId, { kind: "research", content: `Research: ${query}\nAnswer: ${answer.slice(0, 1400)}`, tags: ["research"] });
}

export async function rememberDocument(userId: number, fileName: string, summary: string) {
  return appendMemory(userId, { kind: "document", content: `Document ${fileName}: ${summary.slice(0, 1400)}`, tags: ["document"] });
}


export type ResearchPattern = {
  intent: "compare" | "explain" | "current" | "study" | "code" | "safety" | "general";
  label: string;
  plan: string[];
  suggestedSources: string[];
  ambiguity?: { isAmbiguous: boolean; questions: string[]; interpretations: string[] };
};

function ambiguityFor(query: string) {
  const trimmed = query.trim();
  const questions: string[] = [];
  const interpretations: string[] = [];
  if (trimmed.length < 12) questions.push("What exact outcome or level of detail do you need?");
  if (/\b(it|this|that|they|them)\b/i.test(trimmed)) questions.push("What does the reference word point to?");
  if (/\bpython\b/i.test(trimmed) && !/program|code|snake|animal/i.test(trimmed)) interpretations.push("Python programming", "The Python animal");
  if (/\bapple\b/i.test(trimmed) && !/fruit|iphone|company|mac/i.test(trimmed)) interpretations.push("Apple the company", "apple fruit");
  return { isAmbiguous: questions.length > 0 || interpretations.length > 1, questions, interpretations };
}

function classifyPattern(query: string): ResearchPattern {
  const value = query.toLowerCase();
  if (/(sandbox|escape|bypass|steal|exfiltrat|extend (my|the|your) limit)/i.test(value)) {
    return { intent: "safety", label: "Capability boundary", plan: ["Check whether the request is in scope", "Refuse unsafe escalation plainly", "Offer a safe alternative"], suggestedSources: ["No external sources needed"] };
  }
  if (/(compare|versus|vs\.?|difference|better than|pros and cons)/i.test(value)) {
    return { intent: "compare", label: "Comparison brief", plan: ["Normalize the competing claims", "Collect evidence for each side", "Surface trade-offs and uncertainty"], suggestedSources: ["Primary sources", "Independent analysis"] };
  }
  if (/(latest|today|current|recent|this year|now|news)/i.test(value)) {
    return { intent: "current", label: "Freshness-sensitive research", plan: ["Prioritize recent sources", "Check publication dates", "Flag anything that may have changed"], suggestedSources: ["Current reporting", "Official updates"] };
  }
  if (/(study|exam|learn|revision|homework|explain like|student)/i.test(value)) {
    return { intent: "study", label: "Study coach", plan: ["Explain the core concept", "Build a memorable mental model", "Add practice or recall prompts"], suggestedSources: ["Textbooks", "Educational references"] };
  }
  if (/(code|debug|function|api|typescript|python|javascript|termux|command)/i.test(value)) {
    return { intent: "code", label: "Developer mode", plan: ["Clarify the target environment", "Give a minimal safe example", "Call out assumptions and test steps"], suggestedSources: ["Official documentation", "Runnable examples"] };
  }
  if (/(what is|how does|why does|explain|define|meaning)/i.test(value)) {
    return { intent: "explain", label: "Concept explainer", plan: ["Define the idea plainly", "Add a concrete example", "Distinguish fact from analogy"], suggestedSources: ["Reference material", "Primary documentation"] };
  }
  return { intent: "general", label: "Open research", plan: ["Frame the question", "Collect diverse evidence", "Answer with citations and caveats"], suggestedSources: ["Relevant primary sources", "Independent corroboration"] };
}

export function recognizePattern(query: string): ResearchPattern {
  return { ...classifyPattern(query), ambiguity: ambiguityFor(query) };
}

export async function runDailyReview(userId = 0) {
  const memories = await readMemory(userId, 80);
  const researchItems = memories.filter((item) => item.kind === "research").slice(0, 8);
  const results: Array<{ sourceId: string; status: "checked" | "skipped"; note: string }> = [];
  for (const item of researchItems) {
    const claim = item.content.replace(/^Research:\s*/i, "").split("\nAnswer:")[0].trim();
    if (!claim) {
      results.push({ sourceId: item.id, status: "skipped", note: "No reviewable claim found." });
      continue;
    }
    try {
      const reviewed = await runResearch(`Recheck whether this older research question still has reliable support today: ${claim}`, false);
      const verdict = reviewed.verification?.verdict ?? "needs-review";
      await appendMemory(userId, { kind: "research", content: `Daily proof review for ${claim}: ${verdict}. ${reviewed.caveats ?? ""}`, tags: ["daily-review", verdict] });
      results.push({ sourceId: item.id, status: "checked", note: `Review verdict: ${verdict}` });
    } catch (error) {
      results.push({ sourceId: item.id, status: "skipped", note: `Review unavailable: ${String(error)}` });
    }
  }
  return { reviewedAt: new Date().toISOString(), reviewedCount: results.filter((item) => item.status === "checked").length, results };
}
