import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, documentAnalyses, memoryEntries, researchRuns, users } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { nanoid } from "nanoid";

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb(); if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  }
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  values.lastSignedIn ??= new Date(); updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb(); if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listUserMemory(userId: number, limit = 50) {
  const db = await getDb(); if (!db) return [];
  return db.select().from(memoryEntries).where(eq(memoryEntries.userId, userId)).orderBy(desc(memoryEntries.createdAt)).limit(limit);
}

export async function addUserMemory(userId: number, input: { kind: "context" | "research" | "document"; content: string; tags: string[] }) {
  const db = await getDb(); if (!db) return null;
  const entry = { id: nanoid(12), userId, ...input };
  await db.insert(memoryEntries).values(entry);
  return entry;
}

export async function saveResearchRun(userId: number, query: string, result: unknown) {
  const db = await getDb(); if (!db) return null;
  const id = nanoid(12); const answer = typeof result === "object" && result && "answer" in result ? String((result as { answer: unknown }).answer) : "";
  await db.insert(researchRuns).values({ id, userId, query, answer, result });
  return id;
}

export async function saveDocumentAnalysis(userId: number, fileName: string, mimeType: string, result: unknown) {
  const db = await getDb(); if (!db) return null;
  const id = nanoid(12); await db.insert(documentAnalyses).values({ id, userId, fileName, mimeType, result }); return id;
}
