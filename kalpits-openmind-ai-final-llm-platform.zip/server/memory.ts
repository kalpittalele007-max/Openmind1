import fs from "node:fs/promises";
import path from "node:path";
import { nanoid } from "nanoid";

export type MemoryItem = { id: string; createdAt: string; userId: number; kind: "context" | "research" | "document"; content: string; tags: string[] };
type MemoryFile = { version: 2; items: MemoryItem[] };
const memoryPath = path.resolve(process.cwd(), "data", "openmind-memory.json");
let writeQueue: Promise<unknown> = Promise.resolve();

async function ensureMemoryFile() { await fs.mkdir(path.dirname(memoryPath), { recursive: true }); try { await fs.access(memoryPath); } catch { await fs.writeFile(memoryPath, JSON.stringify({ version: 2, items: [] }, null, 2) + "\n", "utf8"); } }
async function readAll(): Promise<MemoryItem[]> { await ensureMemoryFile(); try { const parsed = JSON.parse(await fs.readFile(memoryPath, "utf8")) as MemoryFile; return Array.isArray(parsed.items) ? parsed.items : []; } catch { return []; } }
function withWriteLock<T>(work: () => Promise<T>): Promise<T> { const result = writeQueue.then(work, work); writeQueue = result.then(() => undefined, () => undefined); return result; }

export async function readMemory(userId: number, limit = 50): Promise<MemoryItem[]> { const items = await readAll(); return items.filter((item) => item.userId === userId).slice(-limit).reverse(); }
export async function appendMemory(userId: number, input: Omit<MemoryItem, "id" | "createdAt" | "userId">) {
  return withWriteLock(async () => { const items = await readAll(); const next: MemoryItem = { ...input, userId, id: nanoid(10), createdAt: new Date().toISOString() }; const userItems = [...items.filter((item) => item.userId === userId), next].slice(-500); const others = items.filter((item) => item.userId !== userId); await fs.writeFile(memoryPath, JSON.stringify({ version: 2, items: [...others, ...userItems] }, null, 2) + "\n", "utf8"); return next; });
}
export function getMemoryPath() { return "user-scoped durable storage"; }
