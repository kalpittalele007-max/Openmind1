import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { appendMemory, getMemoryPath, readMemory } from "./memory";
import { recognizePattern, rememberDocument, rememberResearch, runDailyReview, runDocumentAnalysis, runResearch } from "./research";
import { capabilityStatus } from "./_core/capabilityPolicy";
import { addUserMemory, getDb, listUserMemory, saveDocumentAnalysis, saveResearchRun } from "./db";
import { generateImage } from "./_core/imageGeneration";
import { buildWebsiteBlueprint } from "./websiteBuilder";
import { z } from "zod";
import { runAgent, readFile, writeFile, editFile, listFiles, runShell, inspectShellCommand, listPermissions, setPermission, worktreeCreate, worktreeRemove, worktreeList, startBackground, listTasks, getTask, cancelTask, loadConfig, saveConfig, diagnostics, getMissingCapabilities, capabilityStats, mcpListTools, resolveWorkspace, checkpoint, diffAgainstCheckpoint, preview, createCron, listCrons, deleteCron, createRemoteSession, closeRemoteSession, listRemoteSessions, saveSession, loadSession, compactContext, editNotebookCell } from "./mega";

const featureUser = (user: { id: number }) => user.id;

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
  }),
  research: router({
    prepare: publicProcedure.input(z.object({ query: z.string().max(2000) })).query(({ input }) => recognizePattern(input.query)),
    run: protectedProcedure.input(z.object({ query: z.string().min(1).max(2000), saveToMemory: z.boolean().default(true) })).mutation(async ({ input, ctx }) => {
      const result = await runResearch(input.query, true, featureUser(ctx.user));
      if (input.saveToMemory && result.stance !== "boundary") { await rememberResearch(featureUser(ctx.user), input.query, result.answer); await saveResearchRun(featureUser(ctx.user), input.query, result); }
      return result;
    }),
  }),
  documents: router({
    analyze: protectedProcedure.input(z.object({ fileName: z.string().min(1).max(180).regex(/^[^\\/]+$/), mimeType: z.string().max(120), data: z.string().min(1).max(14_000_000), question: z.string().max(1000).optional(), saveToMemory: z.boolean().default(true) })).mutation(async ({ input, ctx }) => {
      const result = await runDocumentAnalysis(input); const userId = featureUser(ctx.user);
      if (input.saveToMemory) { await rememberDocument(userId, input.fileName, "Document analysis completed."); await saveDocumentAnalysis(userId, input.fileName, input.mimeType, result); }
      return result;
    }),
  }),
  images: router({
    generate: protectedProcedure.input(z.object({ prompt: z.string().min(3).max(2000), style: z.string().max(120).default("editorial cinematic"), aspect: z.enum(["square", "portrait", "landscape"]).default("square") })).mutation(async ({ input }) => {
      const aspectHint = input.aspect === "portrait" ? "vertical portrait composition" : input.aspect === "landscape" ? "wide landscape composition" : "square composition";
      const result = await generateImage({ prompt: `${input.prompt}\nStyle: ${input.style}. Composition: ${aspectHint}. Do not include watermarks or readable text unless explicitly requested.` });
      return { ...result, prompt: input.prompt, aspect: input.aspect, generatedAt: new Date().toISOString() };
    }),
  }),
  websites: router({
    blueprint: protectedProcedure.input(z.object({ prompt: z.string().min(8).max(2000), framework: z.enum(["react", "html", "next"]).default("react") })).mutation(({ input }) => buildWebsiteBlueprint(input.prompt, input.framework)),
  }),
  memory: router({
    list: protectedProcedure.query(async ({ ctx }) => { const userId = featureUser(ctx.user); const db = await getDb(); return { items: db ? await listUserMemory(userId, 50) : await readMemory(userId, 50) }; }),
    reviewNow: protectedProcedure.mutation(({ ctx }) => runDailyReview(featureUser(ctx.user))),
    add: protectedProcedure.input(z.object({ content: z.string().min(1).max(4000), tags: z.array(z.string()).max(8).default(["context"]) })).mutation(async ({ input, ctx }) => { const userId = featureUser(ctx.user); const dbEntry = await addUserMemory(userId, { kind: "context", content: input.content, tags: input.tags }); return dbEntry ?? appendMemory(userId, { kind: "context", content: input.content, tags: input.tags }); }),
  }),
  mega: router({
    inspectCommand: publicProcedure.input(z.object({ command: z.string().min(1).max(4000) })).query(({ input }) => inspectShellCommand(input.command)),
    permissions: router({
      list: protectedProcedure.query(() => listPermissions()),
      set: protectedProcedure.input(z.object({ tool:z.string(), decision:z.enum(["allow-once","allow-always","deny"]), paths:z.array(z.string()).optional(), commands:z.array(z.string()).optional() })).mutation(({input}) => setPermission(input)),
    }),
    files: router({
      read: protectedProcedure.input(z.object({ workspace:z.string().optional(), file:z.string().min(1).max(1000) })).query(({input}) => readFile(resolveWorkspace(input.workspace),input.file)),
      list: protectedProcedure.input(z.object({ workspace:z.string().optional(), pattern:z.string().max(500).optional() })).query(({input}) => listFiles(resolveWorkspace(input.workspace),input.pattern||"")),
      write: protectedProcedure.input(z.object({workspace:z.string().optional(),file:z.string().min(1).max(1000),content:z.string().max(5_000_000)})).mutation(({input}) => writeFile(resolveWorkspace(input.workspace),input.file,input.content)),
      edit: protectedProcedure.input(z.object({workspace:z.string().optional(),file:z.string(),search:z.string().min(1),replacement:z.string()})).mutation(({input}) => editFile(resolveWorkspace(input.workspace),input.file,input.search,input.replacement)),
      notebookCell: protectedProcedure.input(z.object({workspace:z.string().optional(),file:z.string(),index:z.number().int().min(0),source:z.string()})).mutation(({input})=>editNotebookCell(resolveWorkspace(input.workspace),input.file,input.index,input.source)),
    }),
    shell: router({
      run: protectedProcedure.input(z.object({workspace:z.string().optional(),command:z.string().min(1).max(10000),approved:z.boolean().default(false)})).mutation(({input}) => runShell(input.command,resolveWorkspace(input.workspace),{approved:input.approved})),
    }),
    agent: router({
      run: protectedProcedure.input(z.object({prompt:z.string().min(1).max(12000),workspace:z.string().optional(),maxTurns:z.number().int().min(1).max(30).default(12),approved:z.boolean().default(false),model:z.string().optional()})).mutation(async ({input}) => {
        const events=[]; for await (const event of runAgent(input)) events.push(event);
        return events;
      }),
    }),
    worktrees: router({
      list: protectedProcedure.input(z.object({repo:z.string().optional()})).query(({input})=>worktreeList(resolveWorkspace(input.repo))),
      create: protectedProcedure.input(z.object({repo:z.string().optional(),name:z.string().min(1),branch:z.string().min(1)})).mutation(({input})=>worktreeCreate(resolveWorkspace(input.repo),input.name,input.branch)),
      remove: protectedProcedure.input(z.object({repo:z.string().optional(),name:z.string().min(1)})).mutation(({input})=>worktreeRemove(resolveWorkspace(input.repo),input.name)),
    }),
    tasks: router({
      start: protectedProcedure.input(z.object({command:z.string().min(1).max(10000),workspace:z.string().optional(),approved:z.boolean().default(false)})).mutation(({input})=>{
        const check=inspectShellCommand(input.command); if(check.risk!=="low" && !input.approved) throw new Error("Approval required for background command.");
        return startBackground(input.command,resolveWorkspace(input.workspace));
      }),
      list: protectedProcedure.query(()=>listTasks()),
      get: protectedProcedure.input(z.object({id:z.string()})).query(({input})=>getTask(input.id)),
      cancel: protectedProcedure.input(z.object({id:z.string()})).mutation(({input})=>cancelTask(input.id)),
    }),
    artifacts: router({
      checkpoint: protectedProcedure.input(z.object({workspace:z.string().optional(),file:z.string()})).mutation(({input})=>checkpoint(resolveWorkspace(input.workspace),input.file)),
      diff: protectedProcedure.input(z.object({workspace:z.string().optional(),file:z.string()})).query(({input})=>diffAgainstCheckpoint(resolveWorkspace(input.workspace),input.file)),
      preview: protectedProcedure.input(z.object({workspace:z.string().optional(),file:z.string(),lines:z.number().int().min(1).max(500).default(80)})).query(({input})=>preview(resolveWorkspace(input.workspace),input.file,input.lines)),
    }),
    scheduler: router({
      create: protectedProcedure.input(z.object({command:z.string(),workspace:z.string().optional(),intervalMs:z.number().int().min(60000)})).mutation(({input})=>createCron(input.command,resolveWorkspace(input.workspace),input.intervalMs)),
      list: protectedProcedure.query(()=>listCrons()),
      delete: protectedProcedure.input(z.object({id:z.string()})).mutation(({input})=>deleteCron(input.id)),
    }),
    remote: router({
      create: protectedProcedure.mutation(()=>createRemoteSession()),
      list: protectedProcedure.query(()=>listRemoteSessions()),
      close: protectedProcedure.input(z.object({id:z.string()})).mutation(({input})=>closeRemoteSession(input.id)),
    }),
    sessions: router({
      save: protectedProcedure.input(z.object({id:z.string(),messages:z.array(z.object({role:z.string(),content:z.string(),ts:z.string()}))})).mutation(({input})=>saveSession(input.id,input.messages)),
      load: protectedProcedure.input(z.object({id:z.string()})).query(({input})=>loadSession(input.id)),
      compact: protectedProcedure.input(z.object({messages:z.array(z.object({role:z.string(),content:z.string(),ts:z.string()})),maxChars:z.number().int().min(1000).max(500000).optional()})).mutation(({input})=>compactContext(input.messages,input.maxChars)),
    }),
    config: router({
      get: protectedProcedure.query(()=>loadConfig()),
      set: protectedProcedure.input(z.object({model:z.string().optional(),fastModel:z.string().optional(),maxAgentTurns:z.number().int().optional(),outputStyle:z.string().optional(),theme:z.string().optional(),keybindings:z.record(z.string(),z.string()).optional()})).mutation(({input})=>saveConfig(input)),
    }),
    mcp: router({
      listTools: protectedProcedure.input(z.object({id:z.string(),command:z.string(),args:z.array(z.string()).optional()})).query(({input})=>mcpListTools(input)),
    }),
    diagnostics: protectedProcedure.query(()=>diagnostics()),
    capabilities: protectedProcedure.query(()=>({ areas: getMissingCapabilities(), stats: capabilityStats() })),
  }),
  capabilities: router({ check: publicProcedure.query(() => ({ ...capabilityStatus(), safeBoundaryCommand: "no i don't know that yet", maxResearchSeconds: 360, supports: ["web retrieval", "source comparison", "second-pass verification", "two-pass document analysis", "image generation", "website blueprints and starter components", "Termux basics", "study guidance"], refuses: ["sandbox escape", "limit extension", "credential exfiltration", "unsafe destructive commands"] })) }),
});

export type AppRouter = typeof appRouter;
