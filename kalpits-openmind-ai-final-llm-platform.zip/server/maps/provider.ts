/**
 * OpenMind map provider adapter.
 *
 * The supplied map package is preserved under server/maps/supplied-api/.
 * Its two files are opaque/binary and do not expose a documented endpoint,
 * token format, or SDK in a machine-readable form. Therefore this adapter
 * does NOT attempt to decrypt or guess their meaning.
 *
 * Configure a usable map endpoint/key through environment variables instead:
 *   VITE_MAPS_API_BASE_URL
 *   VITE_MAPS_API_KEY
 *
 * The existing Google Maps proxy remains the fallback.
 */
export function mapProviderConfig() {
  return {
    baseUrl: process.env.VITE_MAPS_API_BASE_URL || "",
    hasApiKey: Boolean(process.env.VITE_MAPS_API_KEY),
    suppliedPackageIncluded: true,
  };
}
