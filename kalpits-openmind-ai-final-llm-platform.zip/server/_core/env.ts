export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  // Local-model support: works with Ollama, llama.cpp server, or any
  // OpenAI-compatible local endpoint. No cloud key is required.
  localBaseUrl: process.env.OPENMIND_LOCAL_BASE_URL ?? "http://127.0.0.1:11434/v1",
  localApiKey: process.env.OPENMIND_LOCAL_API_KEY ?? "",
  localModel: process.env.OPENMIND_LOCAL_MODEL ?? "",
  localBackend: (process.env.OPENMIND_LOCAL_BACKEND ?? "ollama") as "ollama" | "llama-cpp" | "openai-compatible",
  localContextWindow: Number(process.env.OPENMIND_LOCAL_CONTEXT ?? 8192),
  defaultModel: process.env.OPENMIND_DEFAULT_MODEL ?? "",
};
