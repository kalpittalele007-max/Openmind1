import { ENV } from "./env";

export type ModelBackend = "gateway" | "openai-compatible" | "ollama" | "llama-cpp";

export type RuntimeModel = {
  id: string;
  backend: ModelBackend;
  baseUrl: string;
  apiKey?: string;
  contextWindow: number;
  capabilities: string[];
};

function cleanBase(url: string) { return url.replace(/\/$/, ""); }

export function getModelRuntime(model?: string): RuntimeModel {
  const requested = model?.trim() || ENV.localModel || ENV.defaultModel || "openmind-local";
  if (ENV.localModel && requested === ENV.localModel) {
    return {
      id: requested,
      backend: ENV.localBackend,
      baseUrl: cleanBase(ENV.localBaseUrl),
      apiKey: ENV.localApiKey || undefined,
      contextWindow: ENV.localContextWindow,
      capabilities: ["chat", "coding", "reasoning", "tool-use"],
    };
  }
  return {
    id: requested,
    backend: "gateway",
    baseUrl: cleanBase(ENV.forgeApiUrl),
    apiKey: ENV.forgeApiKey || undefined,
    contextWindow: 32768,
    capabilities: ["chat", "coding", "reasoning", "tool-use", "multimodal"],
  };
}
