import fs from "node:fs";
import path from "node:path";
const src="data/training/openmind_instruction_corpus.jsonl";
const out="data/training/openmind_sft.jsonl";
const rows=fs.readFileSync(src,"utf8").trim().split(/\r?\n/).map(JSON.parse);
const lines=rows.map(r=>JSON.stringify({messages:[
  {role:"system",content:"You are OpenMind, a precise, truthful, safe and tool-aware AI assistant."},
  {role:"user",content:r.instruction},
  {role:"assistant",content:r.response}
]}));
fs.writeFileSync(out,lines.join("\n")+"\n");
console.log(`Prepared ${rows.length} SFT examples -> ${out}`);
