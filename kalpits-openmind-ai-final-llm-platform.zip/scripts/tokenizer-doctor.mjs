#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
const model=process.argv[2] || 'Qwen/Qwen2.5-0.5B-Instruct';
const r=spawnSync('python',['training/tokenizer.py','--model',model],{stdio:'inherit'});
if(r.error) { console.error(r.error.message); process.exit(1); }
process.exit(r.status ?? 1);
