import fs from "node:fs";
const rows=fs.readFileSync("data/training/openmind_instruction_corpus.jsonl","utf8").trim().split(/\r?\n/).map(JSON.parse);
const required=["math","coding","reasoning","tool-use","research","safety","long-context","multimodal","agent-planning","communication"];
const missing=required.filter(x=>!rows.some(r=>r.category===x));
console.log(JSON.stringify({examples:rows.length,categories:[...new Set(rows.map(r=>r.category))],missingCategories:missing,ready:missing.length===0},null,2));
