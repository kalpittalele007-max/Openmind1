import fs from 'node:fs';
import path from 'node:path';

const input = process.argv[2] || 'data/learning/candidates.jsonl';
const output = process.argv[3] || 'data/learning/verified.jsonl';
if (!fs.existsSync(input)) { console.log('No candidate file; nothing to curate.'); process.exit(0); }
const rows = fs.readFileSync(input,'utf8').split(/\r?\n/).filter(Boolean).map(JSON.parse);
const seen = new Set(); const accepted=[];
for (const r of rows) {
  const text = `${r.instruction}\n${r.response}`.trim();
  const key = text.toLowerCase().replace(/\s+/g,' ');
  const positive = r.verified === true || r.feedback === 'accepted' || r.score >= 0.9;
  const safe = !r.unsafe_training && text.length >= 20 && text.length <= 30000;
  if (positive && safe && !seen.has(key)) { seen.add(key); accepted.push({...r,status:'verified'}); }
}
fs.mkdirSync(path.dirname(output),{recursive:true});
fs.writeFileSync(output, accepted.map(x=>JSON.stringify(x)).join('\n')+(accepted.length?'\n':''));
console.log(JSON.stringify({candidates:rows.length,verified:accepted.length,output},null,2));
