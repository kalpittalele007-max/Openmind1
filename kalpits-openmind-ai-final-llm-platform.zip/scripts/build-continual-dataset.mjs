import fs from 'node:fs';
import path from 'node:path';
const base='data/training/openmind_instruction_corpus.jsonl';
const verified='data/learning/verified.jsonl';
const out='data/training/openmind_continual_sft.jsonl';
const baseRows=fs.readFileSync(base,'utf8').split(/\r?\n/).filter(Boolean).map(JSON.parse);
const extra=fs.existsSync(verified)?fs.readFileSync(verified,'utf8').split(/\r?\n/).filter(Boolean).map(JSON.parse):[];
const rows=[]; const seen=new Set();
for(const r of [...baseRows,...extra]){
 const instruction=r.instruction; const response=r.response;
 if(!instruction||!response) continue;
 const key=`${instruction.trim().toLowerCase()}\n${response.trim().toLowerCase()}`.replace(/\s+/g,' ');
 if(seen.has(key)) continue; seen.add(key);
 rows.push({messages:[
  {role:'system',content:'You are OpenMind, a precise, truthful, safe and tool-aware AI assistant. Verify important claims and never invent tool results.'},
  {role:'user',content:instruction},
  {role:'assistant',content:response}
 ]});
}
fs.mkdirSync(path.dirname(out),{recursive:true});
fs.writeFileSync(out,rows.map(JSON.stringify).join('\n')+'\n');
console.log(`Built ${rows.length} examples -> ${out} (${extra.length} verified additions)`);
