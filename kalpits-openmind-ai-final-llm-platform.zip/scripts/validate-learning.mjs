import fs from "node:fs";
const p="data/training/openmind_instruction_corpus.jsonl";
const rows=fs.readFileSync(p,"utf8").trim().split(/\r?\n/).map(JSON.parse);
const cats=new Map(); for(const r of rows){cats.set(r.category,(cats.get(r.category)||0)+1); if(!r.instruction||!r.response) throw new Error(`invalid ${r.id}`);}
console.log(`Validated ${rows.length} learning examples across ${cats.size} categories.`);
for(const [k,v] of cats) console.log(`${k}: ${v}`);
