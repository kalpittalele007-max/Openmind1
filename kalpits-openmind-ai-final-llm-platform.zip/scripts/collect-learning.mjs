import fs from 'node:fs';
import path from 'node:path';

const out = process.argv[2] || 'data/learning/candidates.jsonl';
const payload = process.argv.slice(3).join(' ');
if (!payload) {
  console.error('Usage: pnpm learning:collect -- <JSON object>');
  process.exit(2);
}
const item = JSON.parse(payload);
if (!item.instruction || !item.response) throw new Error('instruction and response are required');
item.id ||= `candidate-${Date.now()}`;
item.timestamp ||= new Date().toISOString();
item.status ||= 'candidate';
fs.mkdirSync(path.dirname(out), {recursive:true});
fs.appendFileSync(out, JSON.stringify(item)+'\n');
console.log(`Added ${item.id} to ${out}`);
