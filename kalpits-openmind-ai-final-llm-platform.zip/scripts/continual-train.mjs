import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const cfgPath=process.argv[2]||'training/config.json';
if(!fs.existsSync(cfgPath)){fs.copyFileSync('training/config.example.json',cfgPath);console.log(`Created ${cfgPath}; edit base_model/output_dir, then rerun.`);process.exit(0)}
for(const cmd of [
 ['node',['scripts/curate-learning.mjs']],
 ['node',['scripts/build-continual-dataset.mjs']],
 ['node',['scripts/make-holdout.mjs']]
]){const r=spawnSync(cmd[0],cmd[1],{stdio:'inherit'});if(r.status!==0)process.exit(r.status??1)}
const r=spawnSync('python',['training/train_lora.py','--config',cfgPath],{stdio:'inherit'});
process.exit(r.status??1);
