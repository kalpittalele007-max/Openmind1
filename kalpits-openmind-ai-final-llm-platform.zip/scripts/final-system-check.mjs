import fs from 'node:fs';
import path from 'node:path';

const required = [
  'server/_core/modelRuntime.ts',
  'training/tokenizer.py',
  'training/train_lora.py',
  'training/config.example.json',
  'data/training/openmind_instruction_corpus.jsonl',
  'data/training/openmind_continual_sft.jsonl',
  'data/training/openmind_holdout.jsonl',
  'docs/model/CONTINUAL_LEARNING.md',
  'docs/model/LOCAL_LLM.md',
  'mobile/android/app/src/main/java/ai/kalpit/openmind/MainActivity.java'
];

const missing = required.filter(p => !fs.existsSync(path.resolve(p)));
if (missing.length) {
  console.error('Missing required components:', missing);
  process.exit(1);
}
console.log('OpenMind unified LLM platform check: PASS');
console.log('Tokenizer + SFT + continual learning + runtime + Android shell are present.');
console.log('Note: neural-network weights are intentionally external; the repository is not a frontier model checkpoint.');
