import fs from 'node:fs';
const holdout='data/training/openmind_holdout.jsonl';
if(!fs.existsSync(holdout)){console.error('Run pnpm learning:holdout first.');process.exit(2)}
const rows=fs.readFileSync(holdout,'utf8').split(/\r?\n/).filter(Boolean).map(JSON.parse);
const adapter=process.argv[2]||'training/adapters/openmind-latest';
console.log(JSON.stringify({adapter,holdoutExamples:rows.length,gate:'MANUAL/REMOTE MODEL EVALUATION REQUIRED',note:'This script intentionally does not fabricate model scores. Connect your local model endpoint and compare against a fixed baseline before promotion.'},null,2));
