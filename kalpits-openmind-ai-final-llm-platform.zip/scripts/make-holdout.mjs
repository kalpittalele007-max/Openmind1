import fs from 'node:fs';
const src='data/training/openmind_instruction_corpus.jsonl';
const out='data/training/openmind_holdout.jsonl';
const rows=fs.readFileSync(src,'utf8').split(/\r?\n/).filter(Boolean).map(JSON.parse);
const holdout=rows.filter((_,i)=>i%20===0).map(r=>({instruction:r.instruction,expected:r.response,category:r.category}));
fs.writeFileSync(out,holdout.map(JSON.stringify).join('\n')+'\n');
console.log(`Created ${holdout.length}-example holdout -> ${out}`);
