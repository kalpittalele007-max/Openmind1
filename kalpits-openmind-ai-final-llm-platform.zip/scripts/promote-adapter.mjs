import fs from 'node:fs';
import path from 'node:path';
const adapter=process.argv[2]; const score=Number(process.argv[3]); const baseline=Number(process.argv[4]);
if(!adapter||!Number.isFinite(score)||!Number.isFinite(baseline)){console.error('Usage: pnpm learning:promote -- <adapter> <new_score> <baseline_score>');process.exit(2)}
const min=Number(process.env.OPENMIND_MIN_IMPROVEMENT||0.01);
if(score < baseline + min){console.error(`REJECTED: score ${score} did not exceed baseline ${baseline} by ${min}.`);process.exit(1)}
const reg=path.resolve('training/ACTIVE_ADAPTER.json');
fs.mkdirSync(path.dirname(reg),{recursive:true});
const previous=fs.existsSync(reg)?JSON.parse(fs.readFileSync(reg,'utf8')):null;
fs.writeFileSync(reg,JSON.stringify({adapter:path.resolve(adapter),score,baseline,previous,promotedAt:new Date().toISOString()},null,2)+'\n');
console.log(`PROMOTED ${adapter}`);
