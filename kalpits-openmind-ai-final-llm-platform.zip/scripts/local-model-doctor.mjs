const base=(process.env.OPENMIND_LOCAL_BASE_URL||"http://127.0.0.1:11434/v1").replace(/\/$/,"");
const key=process.env.OPENMIND_LOCAL_API_KEY;
try {
  const r=await fetch(`${base}/models`,{headers:key?{authorization:`Bearer ${key}`}:{}});
  if(!r.ok) throw new Error(`${r.status} ${r.statusText}`);
  const j=await r.json();
  console.log(`Local LLM endpoint OK: ${base}`);
  for(const m of (j.data||[])) console.log(`- ${m.id}`);
} catch(e) {
  console.error(`Local LLM unavailable at ${base}: ${e.message}`);
  console.error("Start Ollama/llama.cpp (or another OpenAI-compatible server), then rerun this check.");
  process.exitCode=1;
}
