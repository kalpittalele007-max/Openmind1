# OpenMind AI — Supplied Maps API Integration

The supplied maps archive has been incorporated intact into:

`server/maps/supplied-api/`

Files preserved:
- `app1789705147079i1547384504.a.olf`
- `app1789705147079i1547384504.a.conf`

SHA-256:
- `app1789705147079i1547384504.a.olf`: `a9c99bbe109a24733c788e1c6eb6175df5b78aa553303eb0a1682377377d1bd9`
- `app1789705147079i1547384504.a.conf`: `a6615cd183f300a891ebd1002a1458d3edfa84bd6b4a8d19c7c21e257ece458d`

## Important

These two files are opaque binary data. They do not contain a readable API
endpoint, SDK manifest, or plaintext API key that can be safely identified
from the archive alone. OpenMind therefore stores them without altering or
decrypting them and does not pretend that they are a directly callable API.

The map frontend now supports:

- `VITE_MAPS_API_BASE_URL` — optional map JavaScript API base URL.
- `VITE_MAPS_API_KEY` — optional map API key.
- Existing `VITE_FRONTEND_FORGE_API_URL` + `VITE_FRONTEND_FORGE_API_KEY`
  remain the fallback configuration.

If the supplied API has documentation or a known endpoint/SDK, its binary
package can be wired into `server/maps/provider.ts` without changing the
rest of OpenMind.
