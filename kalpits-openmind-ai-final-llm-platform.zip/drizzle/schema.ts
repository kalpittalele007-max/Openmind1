import { int, json, longtext, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const memoryEntries = mysqlTable("memory_entries", {
  id: varchar("id", { length: 32 }).primaryKey(),
  userId: int("userId").notNull(),
  kind: mysqlEnum("kind", ["context", "research", "document"]).notNull(),
  content: longtext("content").notNull(),
  tags: json("tags").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const researchRuns = mysqlTable("research_runs", {
  id: varchar("id", { length: 32 }).primaryKey(),
  userId: int("userId").notNull(),
  query: text("query").notNull(),
  answer: longtext("answer").notNull(),
  result: json("result").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const documentAnalyses = mysqlTable("document_analyses", {
  id: varchar("id", { length: 32 }).primaryKey(),
  userId: int("userId").notNull(),
  fileName: varchar("fileName", { length: 180 }).notNull(),
  mimeType: varchar("mimeType", { length: 120 }).notNull(),
  result: json("result").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type MemoryEntry = typeof memoryEntries.$inferSelect;
export type ResearchRun = typeof researchRuns.$inferSelect;
export type DocumentAnalysis = typeof documentAnalyses.$inferSelect;
