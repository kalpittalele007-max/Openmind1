CREATE TABLE `document_analyses` (
	`id` varchar(32) NOT NULL,
	`userId` int NOT NULL,
	`fileName` varchar(180) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`result` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `document_analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `memory_entries` (
	`id` varchar(32) NOT NULL,
	`userId` int NOT NULL,
	`kind` enum('context','research','document') NOT NULL,
	`content` longtext NOT NULL,
	`tags` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `memory_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `research_runs` (
	`id` varchar(32) NOT NULL,
	`userId` int NOT NULL,
	`query` text NOT NULL,
	`answer` longtext NOT NULL,
	`result` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `research_runs_id` PRIMARY KEY(`id`)
);
