# Learning data

`candidates.jsonl` is intentionally not shipped. Add candidate examples with `pnpm learning:collect`.

Only examples marked `verified: true`, `feedback: "accepted"`, or `score >= 0.9` are eligible for curation, and `unsafe_training: true` always excludes an example.
