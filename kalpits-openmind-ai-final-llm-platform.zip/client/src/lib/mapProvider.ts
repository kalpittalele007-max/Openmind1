/**
 * Frontend map configuration for OpenMind.
 * Prefer an explicitly configured map API base URL; otherwise use the
 * project's existing Forge Google Maps proxy.
 */
export function getMapProviderConfig() {
  return {
    baseUrl: import.meta.env.VITE_MAPS_API_BASE_URL || "",
    apiKey: import.meta.env.VITE_MAPS_API_KEY || "",
  };
}
