
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TerminalSquare, ShieldCheck, Play, FileCode2, Activity } from "lucide-react";

export default function MegaAgent() {
  const [prompt,setPrompt]=useState("");
  const [command,setCommand]=useState("");
  const [workspace,setWorkspace]=useState(".");
  const [approval,setApproval]=useState(false);
  const [events,setEvents]=useState<any[]>([]);
  const agent=trpc.mega.agent.run.useMutation({onSuccess:e=>setEvents(e as any[])});
  const shell=trpc.mega.shell.run.useMutation({onSuccess:r=>setEvents(x=>[...x,{type:"tool-result",result:r}])});
  const inspect=trpc.mega.inspectCommand.useQuery({command},{enabled:command.trim().length>0});
  const runAgent=()=>{if(prompt.trim()) agent.mutate({prompt,workspace,approved:approval,maxTurns:12});};
  return <div className="min-h-screen bg-background p-4 md:p-8">
    <div className="mx-auto max-w-6xl space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div><div className="flex items-center gap-2 text-xl font-semibold"><TerminalSquare size={21}/> OpenMind Mega Agent</div><p className="text-sm text-muted-foreground">Filesystem + shell + agent loop + Git workflows, guarded by workspace confinement and command-risk checks.</p></div>
        <Badge variant="outline"><ShieldCheck size={13} className="mr-1"/> guarded</Badge>
      </div>
      <Card className="p-4 space-y-3">
        <label className="text-sm font-medium">Workspace</label><Input value={workspace} onChange={e=>setWorkspace(e.target.value)} />
        <label className="text-sm font-medium">Task</label><Textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Inspect the project, identify the problem, edit the necessary files, and run safe tests." rows={5}/>
        <div className="flex gap-2"><Button onClick={runAgent} disabled={agent.isPending}><Play size={15} className="mr-2"/>{agent.isPending?"Working…":"Run agent"}</Button><label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={approval} onChange={e=>setApproval(e.target.checked)}/> approve non-low-risk shell commands for this run</label></div>
      </Card>
      <div className="grid md:grid-cols-2 gap-4">
        <Card className="p-4 space-y-3"><div className="flex items-center gap-2 font-medium"><TerminalSquare size={16}/> Terminal</div><Input value={command} onChange={e=>setCommand(e.target.value)} placeholder="pwd / git status / npm test"/>
          {command && <div className="text-xs text-muted-foreground">Risk: <b>{inspect.data?.risk ?? "checking…"}</b> {inspect.data?.reasons?.join(" ")}</div>}
          <Button variant="secondary" onClick={()=>shell.mutate({workspace,command,approved:approval})} disabled={!command.trim()||shell.isPending}>Execute</Button>
        </Card>
        <Card className="p-4 space-y-2"><div className="flex items-center gap-2 font-medium"><Activity size={16}/> Event log</div><pre className="max-h-96 overflow-auto rounded-md bg-muted p-3 text-xs whitespace-pre-wrap">{events.length?events.map((e,i)=>`[${i+1}] ${e.type}: ${JSON.stringify(e.content ?? e.result ?? e.summary ?? e.call ?? e.status)}`).join("\n\n"):"No agent events yet."}</pre></Card>
      </div>
      <Card className="p-4 text-sm text-muted-foreground"><FileCode2 size={15} className="inline mr-2"/>The agent can read, write, edit and search files inside the configured workspace. It cannot escape that workspace, and blocked shell patterns are rejected before execution.</Card>
    </div>
  </div>
}
