#!/usr/bin/env python3
"""OpenMind tokenizer utility.
The tokenizer is coupled to the selected base model and is saved with each adapter.
"""
import argparse, json
from pathlib import Path

def load_tokenizer(model_id_or_path, trust_remote_code=False):
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(model_id_or_path, use_fast=True, trust_remote_code=trust_remote_code)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token or tok.unk_token
    if tok.pad_token is None:
        raise RuntimeError('Tokenizer has no usable pad/eos/unk token.')
    return tok

def main():
    p=argparse.ArgumentParser(description='Inspect/tokenize with the OpenMind base-model tokenizer')
    p.add_argument('--model',required=True); p.add_argument('--text'); p.add_argument('--file')
    p.add_argument('--max-length',type=int,default=1024); p.add_argument('--save'); p.add_argument('--trust-remote-code',action='store_true')
    a=p.parse_args()
    try: tok=load_tokenizer(a.model,a.trust_remote_code)
    except ImportError as e: raise SystemExit(f'Missing dependency: {e}. Install training/requirements.txt')
    if a.file: text=Path(a.file).read_text(encoding='utf-8')
    else: text=a.text
    info={'name_or_path':getattr(tok,'name_or_path',a.model),'vocab_size':len(tok),'fast':getattr(tok,'is_fast',False),'model_max_length':tok.model_max_length,'pad_token':tok.pad_token,'pad_token_id':tok.pad_token_id,'eos_token':tok.eos_token,'eos_token_id':tok.eos_token_id,'bos_token':tok.bos_token,'unk_token':tok.unk_token,'special_tokens':tok.special_tokens_map}
    if text is not None:
        enc=tok(text,truncation=True,max_length=a.max_length,return_attention_mask=True)
        info.update({'tokens':len(enc['input_ids']),'input_ids':enc['input_ids']})
    print(json.dumps(info,indent=2,ensure_ascii=False))
    if a.save:
        Path(a.save).mkdir(parents=True,exist_ok=True); tok.save_pretrained(a.save); print(f'Tokenizer saved to {a.save}')
if __name__=='__main__': main()
