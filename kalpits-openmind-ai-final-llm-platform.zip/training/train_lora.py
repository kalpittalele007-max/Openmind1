#!/usr/bin/env python3
"""Opt-in LoRA/QLoRA trainer for OpenMind.

Trains an adapter, not a foundation model. It is deliberately separate from
the live server so a failed experiment cannot mutate the active model.
"""
import argparse, json
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description='Fine-tune an OpenMind adapter with LoRA/QLoRA')
    p.add_argument('--config',default='training/config.json')
    args=p.parse_args()
    try:
        import torch
        from datasets import load_dataset
        from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments, Trainer, DataCollatorForLanguageModeling
        from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
    except ImportError as e:
        raise SystemExit(f'Missing training dependency: {e}. Install: pip install -r training/requirements.txt')

    cfg=json.loads(Path(args.config).read_text())
    base=cfg['base_model']; dataset=cfg['dataset']; out=Path(cfg['output_dir']); out.mkdir(parents=True,exist_ok=True)
    if not Path(dataset).exists(): raise SystemExit(f'Dataset not found: {dataset}. Run pnpm learning:prepare first.')

    tokenizer=AutoTokenizer.from_pretrained(base, use_fast=True)
    if tokenizer.pad_token is None: tokenizer.pad_token=tokenizer.eos_token or tokenizer.unk_token
    if tokenizer.pad_token is None: raise SystemExit('Base model tokenizer has no usable pad/eos/unk token')

    model_kwargs={}
    quantized=False
    if cfg.get('quantize_4bit') and torch.cuda.is_available():
        try:
            from transformers import BitsAndBytesConfig
            model_kwargs['quantization_config']=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_compute_dtype=torch.float16,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True)
            quantized=True
        except Exception as e:
            print(f'4-bit quantization unavailable; using full precision: {e}')
    model=AutoModelForCausalLM.from_pretrained(base, **model_kwargs)
    if quantized:
        model=prepare_model_for_kbit_training(model)

    ds=load_dataset('json',data_files=dataset,split='train')
    max_len=int(cfg.get('max_seq_length',1024))

    def render(row):
        messages=row['messages']
        if hasattr(tokenizer,'apply_chat_template'):
            text=tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=False)
        else:
            text='\n'.join(f"{m['role']}: {m['content']}" for m in messages)
        return {'text':text}
    ds=ds.map(render,remove_columns=ds.column_names)
    def tokenize(row):
        enc=tokenizer(row['text'],truncation=True,max_length=max_len,padding=False)
        enc['labels']=enc['input_ids'].copy()
        return enc
    ds=ds.map(tokenize,remove_columns=['text'])

    lora=LoraConfig(r=int(cfg.get('lora_r',8)),lora_alpha=int(cfg.get('lora_alpha',16)),lora_dropout=float(cfg.get('lora_dropout',0.05)),bias='none',task_type='CAUSAL_LM',target_modules=cfg.get('target_modules',['q_proj','k_proj','v_proj','o_proj']))
    model=get_peft_model(model,lora)
    model.print_trainable_parameters()

    ta=TrainingArguments(output_dir=str(out),num_train_epochs=float(cfg.get('epochs',1)),learning_rate=float(cfg.get('learning_rate',2e-4)),per_device_train_batch_size=1,gradient_accumulation_steps=int(cfg.get('gradient_accumulation_steps',8)),logging_steps=10,save_strategy='epoch',report_to='none',fp16=bool(torch.cuda.is_available()),gradient_checkpointing=True)
    trainer=Trainer(model=model,args=ta,train_dataset=ds,data_collator=DataCollatorForLanguageModeling(tokenizer=tokenizer,mlm=False))
    trainer.train(); trainer.save_model(str(out)); tokenizer.save_pretrained(str(out))
    (out/'TRAINING_METADATA.json').write_text(json.dumps({'base_model':base,'examples':len(ds),'max_seq_length':max_len,'quantized_4bit':quantized,'adapter':'LoRA','tokenizer': {'name_or_path': getattr(tokenizer,'name_or_path',base), 'vocab_size': len(tokenizer), 'is_fast': getattr(tokenizer,'is_fast',False), 'pad_token_id': tokenizer.pad_token_id, 'eos_token_id': tokenizer.eos_token_id},'config':cfg},indent=2)+'\n')
    print(f'Adapter written to {out}')

if __name__=='__main__': main()
