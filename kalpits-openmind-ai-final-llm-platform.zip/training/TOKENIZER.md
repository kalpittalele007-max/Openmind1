# OpenMind tokenizer

OpenMind now treats the **base-model tokenizer as part of the model artifact**. The tokenizer supplies the vocabulary, token IDs, special tokens, and chat template used by the neural network.

Inspect it:

```bash
python training/tokenizer.py --model Qwen/Qwen2.5-0.5B-Instruct
```

Tokenize text:

```bash
python training/tokenizer.py --model Qwen/Qwen2.5-0.5B-Instruct --text "Hello OpenMind"
```

Save a copy:

```bash
python training/tokenizer.py --model Qwen/Qwen2.5-0.5B-Instruct --save training/adapters/openmind-latest/tokenizer
```

The LoRA trainer loads the tokenizer from the same `base_model` and saves it with the adapter. Do not mix a tokenizer from another model family with the model weights.

Continual learning keeps the tokenizer fixed. New words can normally be represented by existing subword pieces. Vocabulary expansion is a separate experiment because it requires resizing and retraining/re-evaluating the relevant embedding/output layers.
