# OpenMind Continual Learning Pipeline

This directory adds a guarded continual-learning workflow. It does **not** change model weights from raw conversations automatically.

Flow:

1. Collect candidate interactions in `data/learning/candidates.jsonl`.
2. Curate only examples with explicit positive feedback or an independently verified correction.
3. Deduplicate and validate them.
4. Merge with the base OpenMind SFT corpus.
5. Fine-tune an open-weight causal LM with LoRA/QLoRA.
6. Evaluate the new adapter against a fixed holdout set.
7. Promote only if the evaluation gate passes; otherwise keep the previous adapter.

The trainer is intentionally opt-in. It will never train from arbitrary user conversations without a quality signal.
