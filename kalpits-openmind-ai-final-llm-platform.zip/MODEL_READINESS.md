# OpenMind unified LLM readiness

This release combines the tokenizer, supervised-training corpus, continual-learning pipeline, model runtime, and agent platform.

It is important to distinguish three layers:
1. OpenMind application/agent code.
2. A tokenizer compatible with the selected base model.
3. Actual neural-network weights.

The repository can prepare and fine-tune an open-weight model, but it does not contain frontier-model weights and does not claim to have trained them. Put a compatible open-weight model behind the local runtime, then run the LoRA/QLoRA pipeline. The tokenizer must come from the same model family unless the training configuration explicitly specifies another compatible tokenizer.

Recommended promotion flow:
- validate tokenizer
- validate training data
- train an adapter
- run the holdout benchmark
- compare against the baseline
- promote only if the evaluation gate passes
- retain the previous adapter for rollback

This prevents the continual learner from silently replacing a better model with a regressed checkpoint.
