# KALPIT's OpenMind AI

KALPIT's OpenMind AI is a dark, research-first AI workspace for questions that benefit from **web retrieval, source comparison, second-pass verification, and clear uncertainty labels**. It also includes a two-pass document analyzer, persistent context memory, predictive intent planning, daily proof-review hooks, study guidance, safe Termux basics, and an explicit capability boundary for requests that ask the assistant to escape its sandbox or extend its limits.

## What it does

- **Research mode:** retrieves public web results, fetches a bounded set of source pages, synthesizes an answer, then runs a second skeptical verification pass.
- **Document mode:** runs a first pass for key points/entities/outline and a second pass for main points, summary, answer, caveats, and next steps.
- **Memory:** feature routes require a signed-in user; memory is scoped by user. Hosted deployments use the Drizzle tables from `drizzle/0001_bouncy_vindicator.sql`; the local fallback is user-scoped and write-serialized.
- **Safe boundaries:** responds with `No — I don't know that yet` for sandbox escape, limit extension, credential exfiltration, or similar out-of-scope requests.
- **Pattern recognition:** recognizes comparison, current-events, study, coding, explainer, and safety intents while the user is typing and prepares a visible plan before send.
- **Knowledge freshness:** supports a deploy-safe daily callback at `/api/scheduled/daily-review` plus a manual “check now” action. It rechecks saved research against current evidence and records the verdict in memory.
- **Study + Termux guidance:** the interface provides starter prompts and the backend can answer scoped educational and command-line questions without executing arbitrary commands.
- **Image Studio:** authenticated users can describe an image, generate it through the server-side image service, preview it, and download it. Image-service credentials never reach the browser.
- **Upload transparency:** text and PDF files are supported for analysis; other formats are stored with a visible extraction warning unless a dedicated parser is added.

## Local setup

```bash
pnpm install
pnpm dev
```

The hosted WebDev template injects `BUILT_IN_FORGE_API_URL` and `BUILT_IN_FORGE_API_KEY` for server-side LLM calls. For local runs, provide those values in your shell or through your own secret manager. **Never commit API keys.** The key included in the original request was not written to this repository or ZIP.

For durable production search, set `BRAVE_SEARCH_API_KEY`; when it is absent, the app uses bounded public fallback retrieval and clearly records source-fetch limitations.

## GitHub notes

This repository is structured as a standard Vite + React + Tailwind + Express + tRPC + Drizzle application. It is safe to push to GitHub after checking that no local `.env` files, database dumps, or generated secrets are present.

```bash
git init
git add .
git commit -m "Build KALPIT's OpenMind AI"
git branch -M main
git remote add origin https://github.com/YOUR_USER/YOUR_REPO.git
git push -u origin main
```

## Architecture

- `client/src/pages/Home.tsx` contains the workspace UI.
- `server/research.ts` contains retrieval, bounded source fetching, LLM synthesis, verification, and document analysis.
- `server/research.ts` also contains intent planning and daily proof review.
- `server/routers.ts` exposes typed tRPC procedures.
- `server/memory.ts` manages the auto-created JSON memory file.
- `server/security.ts` supplies public-URL validation, redirect checks, retry/backoff, headers, and API throttling.
- `server/_core/imageGeneration.ts` provides the server-only image-generation integration.
- `server/auth.protection.test.ts` verifies that research execution, document analysis, and memory routes reject unauthenticated callers.
- `CONTRIBUTING.md` and `.github/workflows/ci.yml` provide the post-GitHub developer handoff and automated checks.
- `drizzle/schema.ts` remains ready for durable user-scoped persistence as the product grows.

## Important limitations

The application is designed for bounded, user-initiated research and does not promise a universal fact checker. Public pages can be unavailable, stale, or contradictory. The interface shows the source list, verification verdict, tests, confidence, and caveats so the user can judge the result. The maximum research budget is six minutes at the application layer, while individual network requests use shorter timeouts, retry/backoff, and public-URL validation to keep the UX responsive and reduce SSRF risk.

**What it is not capable of** (also returned by the public, unauthenticated `capabilities.check` endpoint as `notCapableOf`):

- Running its own frontier-scale foundation model — it calls an external LLM provider
- Real-time voice conversation (speech-to-speech) or continuous listening
- Seeing, controlling, or acting on your screen, mouse, or keyboard
- Logging into websites or completing purchases/forms on your behalf
- Understanding or generating video
- Autonomous, unsupervised multi-agent coordination without human review
- Running as an always-on background worker without an actual deployed scheduler
- Guaranteeing every web source it cites is accurate, current, or unbiased
- Acting as a replacement for a licensed doctor, lawyer, financial advisor, or auditor
- Remembering everything forever — memory is limited to what is actually stored and retained
- Bypassing its own safety boundaries, sandbox, or rate limits, even if asked
- Guaranteeing absolute security or claiming superiority over other AI systems without evidence


## Major missing capabilities (roadmap)

This section tracks the capability gap between KALPIT's OpenMind AI and a full frontier-grade AI platform, organized into 35 capability areas.

### 1. Frontier foundation model
Own large-scale foundation model; frontier-level general, coding, mathematical, and scientific reasoning; native instruction-following, tool-use, and agentic reasoning training.

### 2. Advanced reasoning
Deep multi-step reasoning; reliable complex problem solving; advanced mathematical and scientific reasoning; long-horizon planning; self-correction at the model level; robust ambiguity resolution; reliable reasoning across unfamiliar domains.

### 3. Unified multimodal model
Native text + image, audio, video, and document + image reasoning; unified multimodal context; real-time multimodal interaction.

### 4. Advanced voice
Real-time conversational voice; low-latency speech-to-speech; natural interruption handling and turn-taking; continuous listening state; voice emotion/prosody handling; unified voice + vision + reasoning; production-grade realtime audio pipeline.

### 5. Advanced computer use
Reliable visual computer control; screen understanding; mouse/keyboard control; application and browser interaction; GUI navigation; visual verification after actions; recovery from unexpected UI states.

### 6. Advanced web agent
Autonomous web navigation; multi-step browser interaction; login workflows; form completion; automatic query refinement; cross-source contradiction detection; long-running research sessions; automatic research planning and verification.

### 7. Production coding agent
Frontier-level coding model; deep repository understanding; reliable multi-file implementation; automatic debugging, test generation/repair; build-error recovery; dependency debugging; architecture-level refactoring; regression detection; reliable completion verification.

### 8. Secure agent sandbox
OS-level filesystem and network sandboxing; process isolation; CPU/memory resource limits; network and filesystem allowlists; disposable execution environments; container/VM isolation; automatic environment cleanup.

### 9. Advanced prompt-injection defense
Tool-result and web-page injection detection; malicious README/repository-instruction detection; indirect prompt-injection and context poisoning detection; tool-output sanitization; agent instruction hierarchy enforcement; continuous prompt-injection evaluation.

### 10. Advanced tool use
Model-native tool selection and learned tool planning; tool-result interpretation; automatic retry and failure recovery; parallel and dependency-aware tool planning; tool-call optimization and verification.

### 11. Large-scale model routing
Automatic model selection across fast, reasoning, coding, vision, long-context, and research models; cost-, latency-, and capability-aware routing; automatic fallback models.

### 12. Advanced context management
Extremely large context windows; intelligent prioritization and learned compression; semantic memory retrieval; automatic relevance ranking; cross-session context reconstruction; long-running agent context; context conflict and poisoning resolution.

### 13. Advanced memory
Structured long-term, episodic, semantic, project, and user-preference memory; automatic memory formation; relevance scoring; conflict resolution; decay; provenance; safety controls.

### 14. Multi-agent system
Advanced coordinator agent; specialized and parallel worker agents; agent delegation, result verification, and conflict resolution; agent-to-agent planning; dynamic worker spawning/termination; shared structured workspace.

### 15. Advanced MCP
Full MCP client and server; stdio, SSE, and WebSocket transports; dynamic tool/resource discovery; resource subscriptions; tool permission management; MCP security isolation and server trust management.

### 16. Advanced background agents
Persistent autonomous agents; long-running and scheduled tasks; event-triggered agents; retry policies and failure recovery; agent health monitoring; persistent task queues; distributed execution; reliable task resumption.

### 17. Advanced git/development workflow
Automatic branch/worktree management; automatic commit generation and verification; PR generation and review; merge conflict resolution; automatic rollback; CI integration; release workflow automation.

### 18. IDE integration
VS Code, JetBrains, and remote IDE integration; editor diagnostics; inline AI coding; code navigation; symbol-aware editing; integrated terminal; debugger and breakpoint-aware AI debugging.

### 19. Desktop/OS integration
Native desktop application and installers; automatic updates; system notifications; OS-level integration; native terminal integration; secure credential storage; background service management.

### 20. Model infrastructure
Distributed model serving; GPU inference infrastructure; model/tensor/pipeline parallelism; KV-cache optimization; dynamic batching; load balancing; high-availability inference; model replication; global inference routing.

### 21. Model training
Large-scale pretraining; instruction tuning; preference optimization; reinforcement learning; reasoning, tool-use, coding, multimodal, and safety training; continual training.

### 22. AI safety infrastructure
Automated red-team, jailbreak, prompt-injection, tool-abuse, data-exfiltration, and dangerous-command testing; model behavior monitoring; safety regression testing; policy enforcement at the model level.

### 23. Large-scale evaluation
Massive benchmark suite spanning coding, reasoning, math, science, long-context, hallucination, tool-use, agent, multimodal, and prompt-injection benchmarks; continuous regression testing.

### 24. Production observability
Distributed tracing; model/agent/tool telemetry; token accounting; latency, error, and cost monitoring; performance dashboards; automatic anomaly detection; production incident analysis.

### 25. Enterprise-grade security
Secrets management; credential isolation; OAuth integration; fine-grained/role-based access control; audit logs; encryption at rest and in transit; org- and user-level policies; data-loss prevention.

### 26. Advanced file/document intelligence
Native document vision; table and complex spreadsheet reasoning; scanned-document understanding; OCR + reasoning; cross-document reasoning; citation-level evidence tracking; document contradiction detection; large-document autonomous investigation.

### 27. Advanced image generation/understanding
Native vision model; image editing and reasoning; image-to-image understanding; visual grounding; object-level reasoning; diagram and screenshot reasoning; consistent image generation; image-generation evaluation.

### 28. Advanced video intelligence
Video understanding, temporal reasoning, and scene understanding; object tracking; video summarization and question answering; video generation and AI-assisted editing; long-video analysis.

### 29. Real-time information system
Live data ingestion; streaming information processing; real-time event detection and source verification; real-time alerts; continuous monitoring agents; event-driven agent execution.

### 30. Self-evaluating agent
Automatic answer verification; independent critic model; automatic test generation and adversarial testing; confidence calibration; failure classification; root-cause analysis; automatic retry strategy; evidence-based completion verification.

### 31. Autonomous research system
Research planning; source discovery and ranking; query decomposition; iterative research; evidence extraction; contradiction detection; evidence graph; automatic fact verification; research report generation.

### 32. General agent memory + knowledge graph
Entity and relationship graphs; temporal knowledge; source provenance; confidence tracking; knowledge updates; contradiction resolution; project-specific knowledge graphs.

### 33. High-reliability agent loop
Plan → execute → observe → verify → critique → correct → retry → test → confirm → complete.

### 34. Global scale
Multi-region deployment; high availability; automatic failover; horizontal scaling; distributed databases and queues; CDN integration; global monitoring; disaster recovery.

### 35. Frontier-model research capability
Large-scale experimentation; model fine-tuning; distillation; synthetic-data generation; reinforcement learning environments; automated model evaluation; model ablation testing; training-data and architecture experiments.

## Mega AI coding agent

The `/mega` workspace and `npm run mega` CLI add guarded terminal-native coding workflows. See `docs/mega-agent.md` for the capability matrix, architecture and deployment notes.

## Standalone/local model runtime

OpenMind now supports an optional local LLM backend through an OpenAI-compatible endpoint. Configure `OPENMIND_LOCAL_BASE_URL` and `OPENMIND_LOCAL_MODEL` for Ollama, llama.cpp server, or another compatible local server. Use `pnpm model:doctor` to check the endpoint and `pnpm training:prepare` to convert the bundled behavioral corpus into standard chat/SFT JSONL.

The bundled corpus is training/evaluation data; it is not neural-network weights. Actual model weights must be supplied by an open-weight model and served locally or by a configured model provider.

## Continual learning / self-training

OpenMind includes an opt-in LoRA/QLoRA continual-learning pipeline under `training/`. It collects explicitly verified examples, filters and deduplicates them, builds a training set, trains an adapter outside the live server, evaluates against a fixed holdout, and promotes only a measured improvement. See `docs/model/CONTINUAL_LEARNING.md`.
