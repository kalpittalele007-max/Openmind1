# OpenMind local LLM runtime

OpenMind can now run against a local OpenAI-compatible model endpoint instead of requiring the hosted gateway.

Supported endpoint styles:
- Ollama OpenAI-compatible API: `http://127.0.0.1:11434/v1`
- llama.cpp server: `http://127.0.0.1:8080/v1`
- Any compatible `/v1/chat/completions` + `/v1/models` server

Configure `OPENMIND_LOCAL_BASE_URL`, `OPENMIND_LOCAL_MODEL`, and optionally `OPENMIND_LOCAL_API_KEY`. The local endpoint is selected when the requested model matches `OPENMIND_LOCAL_MODEL`.

This is runtime support, not a claim that the repository contains trained neural-network weights. To obtain a standalone model, install/download an open-weight model separately and serve it through one of the supported runtimes.
