# OpenMind continual learning

OpenMind now has a guarded self-training pipeline. "Self-training" here means the system can identify and curate verified examples, periodically fine-tune an adapter, evaluate it against a fixed holdout, and promote it only after a measurable improvement. It does not silently change model weights from raw conversations.

## Quick start

```bash
pnpm learning:holdout
pnpm learning:prepare
cp training/config.example.json training/config.json
# edit training/config.json and choose an open-weight instruct model
pnpm learning:train
pnpm learning:eval -- training/adapters/openmind-latest
```

To add a verified learning example:

```bash
pnpm learning:collect -- '{"instruction":"Explain recursion","response":"...","verified":true,"feedback":"accepted"}'
pnpm learning:curate
pnpm learning:prepare
```

The training script uses LoRA/QLoRA where supported. The base model remains unchanged and the result is an adapter. This is appropriate for low-cost customization; it is not foundation-model pretraining.

## Promotion gate

Never promote an adapter merely because training completed. Run the same holdout suite against the old and new model, then:

```bash
pnpm learning:promote -- training/adapters/openmind-latest NEW_SCORE BASELINE_SCORE
```

Promotion requires the configured minimum improvement (default 0.01). A previous adapter is retained in `training/ACTIVE_ADAPTER.json` so rollback is explicit.

## Safety rules

- Raw user conversations are not automatically training data.
- Only explicit positive feedback or independent verification can create a training candidate.
- Candidate data is deduplicated and length-checked.
- Evaluation uses a fixed holdout that is not used for training.
- Training occurs outside the live server process.
- A failed evaluation does not replace the active adapter.
- Current facts should generally be handled by retrieval/RAG rather than baked into weights.
