# OpenMind model-training pipeline

The repository now has a reproducible preparation path from its behavioral corpus to supervised fine-tuning (SFT) JSONL. `pnpm training:prepare` creates `data/training/openmind_sft.jsonl`.

Recommended practical path for a phone/low-RAM environment:
1. Prepare the SFT dataset with the command above.
2. Fine-tune a small open-weight instruct model on a stronger machine or hosted GPU using LoRA/QLoRA.
3. Export/quantize the resulting model (for example GGUF where supported).
4. Serve it with Ollama or llama.cpp.
5. Point OpenMind at that local OpenAI-compatible endpoint.
6. Run `pnpm mega:eval` and compare the fine-tuned model against the base model.

OpenMind intentionally does not pretend to contain pretrained weights or to have trained them inside this source archive.
