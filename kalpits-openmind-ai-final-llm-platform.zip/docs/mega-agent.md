# OpenMind Mega AI — Capability Upgrade

This build adds a guarded coding-agent subsystem to KALPIT's OpenMind AI. It is an independent implementation, not a claim that any supplied third-party archive is authentic.

Implemented in this archive:
- Workspace-confined filesystem read/write/edit/search and file preview.
- Notebook cell editing for `.ipynb`.
- Checkpoint files and structured line-oriented diffs.
- Shell execution with risk classification, blocked dangerous patterns, workspace confinement, timeouts, output truncation, and explicit approval for non-low-risk commands.
- Agentic tool loop with model → tool request → permission/risk check → execution → result → continuation.
- Persistent permission records in `.openmind/permissions.json`.
- Background processes, task status, cancellation, and interval scheduler.
- Git worktree creation/list/removal through the guarded shell layer.
- Session save/load and deterministic context compaction.
- Project configuration in `.openmind/config.json`.
- MCP stdio `tools/list` discovery.
- Remote-session lifecycle primitives.
- Runtime diagnostics.
- Slash-command and built-in skill registries.
- Web UI at `/mega` for the agent and terminal.
- Existing research, document analysis, image, website, memory, voice and capability-policy subsystems remain in place.

Architecture intentionally differs from simply copying another product:
`UI → tRPC → Mega Agent → Tool Registry → Permission/Security → Workspace/Shell → results → Agent`
The LLM remains the planner; the application owns tool execution and policy enforcement.

Not yet equivalent to a full desktop terminal product:
- A native Ink/Vim TUI is not included.
- PowerShell execution is not assumed on Android/Linux.
- Remote WebSocket transport requires deployment wiring; the remote-session API is present.
- MCP SSE/WebSocket transports are not implemented by the stdio adapter.
- True OS-level cron/daemon supervision is environment-dependent; the scheduler is process-local.
- Multi-agent workers are represented by the agent/tool architecture but do not yet provide a full distributed worker fabric.
- Native IDE installers/updaters and heap-dump tooling are platform-specific and are not fabricated as working features.
- Voice streaming uses the existing OpenMind voice infrastructure rather than duplicating a second audio stack.

Security model:
1. Every filesystem path is resolved under the configured workspace.
2. Blocked shell patterns are rejected before execution.
3. Low-risk allowlisted commands can execute without an approval flag.
4. Medium/high-risk commands require explicit approval.
5. Permissions can be persisted, but this build does not silently elevate or bypass OS permissions.
6. Tool outputs are bounded to avoid runaway context growth.

Start:
1. `npm install`
2. `npm run check`
3. `npm run dev`
4. Open `/mega`.

For Android/Termux, set `OPENMIND_WORKSPACE` to the project directory you want the agent to operate in. Keep it away from system directories and personal secrets.
