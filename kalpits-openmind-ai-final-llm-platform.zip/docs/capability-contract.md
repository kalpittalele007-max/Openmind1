# OpenMind Capability Contract

This layer is an additive guardrail around the existing application. It does not
make impossible guarantees; instead it makes OpenMind explicitly truthful about
its capabilities and prevents the model from representing unavailable access,
execution, security, memory, or update guarantees as facts.

The contract is injected at `server/_core/llm.ts`, the common LLM boundary, so
existing research and document-analysis flows receive it without rewriting
their individual prompts.

Important implementation limits:

- "Completely correct" cannot be guaranteed by an LLM.
- Internet sources cannot all be guaranteed reliable, current, or unbiased.
  The research pipeline should evaluate freshness, authority, corroboration,
  and conflicts.
- Professional-domain answers remain informational support.
- Private/authenticated resources require an authorized integration.
- Code execution requires an explicit reviewed execution path; this repository
  does not silently execute generated code.
- Destructive/irreversible actions require explicit authorization and a real
  action tool.
- Daily review is only real when a scheduler actually invokes the existing
  `/api/scheduled/daily-review` endpoint.
- Memory is bounded by the application's configured storage; it is not
  guaranteed to remember everything permanently.
- Security cannot be certified absolutely by this layer.

The capability status is also exposed through the existing `capabilities.check`
tRPC procedure.
