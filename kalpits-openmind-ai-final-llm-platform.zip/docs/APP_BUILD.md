# Building OpenMind as an Android app

The repository is a web application (Vite + React + Express). The safest mobile architecture is a thin Android shell around the OpenMind web UI/backend rather than trying to put a full Node/Python training stack inside the APK.

For a phone-only workflow:
1. Run the OpenMind server in Termux.
2. Build the Android shell with an Android-capable IDE or Gradle environment.
3. Point the shell at the OpenMind server URL.
4. Keep model training on a machine/cloud with sufficient memory; keep inference and the UI separate when the phone cannot hold the model.

For a desktop workflow, Android Studio is Google's official Android IDE. See the official Android developer documentation before installing/building.

The shell included here is intentionally small. It does not embed model weights in the APK. Model weights can be large and should be managed separately.
